@echo off
setlocal
cd /d "%~dp0"
echo === Mindful Policy Deep Agent ===

where py >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python 3.11 or newer from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^) and run this again.
  pause & exit /b 1
)
if not exist .venv (
  echo Creating virtual environment...
  py -3 -m venv .venv || (echo Could not create the virtual environment. & pause & exit /b 1)
)
if not exist .venv\.installed (
  echo Installing Python packages ^(first run only, a few minutes^)...
  .venv\Scripts\python -m pip install --upgrade pip >nul
  .venv\Scripts\python -m pip install -r requirements.txt || (echo Package install failed. & pause & exit /b 1)
  echo ok> .venv\.installed
)
if not exist .env copy .env.example .env >nul

where ollama >nul 2>nul
if errorlevel 1 (
  echo.
  echo WARNING: Ollama is not installed. Get it free from https://ollama.com/download then run:  ollama pull qwen3:8b
  echo The app will still open and show what is missing.
) else (
  ollama list | findstr /i "qwen3:8b" >nul || (echo Downloading the model qwen3:8b ^(about 5 GB, first run only^)... & ollama pull qwen3:8b)
)
echo.
.venv\Scripts\python run.py
pause
