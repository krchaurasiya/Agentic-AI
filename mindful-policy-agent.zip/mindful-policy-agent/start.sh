#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "=== Mindful Policy Deep Agent ==="
PY=$(command -v python3.12 || command -v python3.11 || command -v python3 || true)
[ -z "$PY" ] && { echo "Python 3.11+ not found. Install it from https://www.python.org/downloads/"; exit 1; }
[ -d .venv ] || "$PY" -m venv .venv
if [ ! -f .venv/.installed ]; then
  echo "Installing Python packages (first run only, a few minutes)..."
  .venv/bin/python -m pip install --upgrade pip >/dev/null
  .venv/bin/python -m pip install -r requirements.txt
  touch .venv/.installed
fi
[ -f .env ] || cp .env.example .env
if command -v ollama >/dev/null 2>&1; then
  ollama list 2>/dev/null | grep -qi "qwen3:8b" || { echo "Downloading model qwen3:8b (about 5 GB, first run only)..."; ollama pull qwen3:8b; }
else
  echo "WARNING: Ollama is not installed. Get it free from https://ollama.com/download then run: ollama pull qwen3:8b"
fi
exec .venv/bin/python run.py
