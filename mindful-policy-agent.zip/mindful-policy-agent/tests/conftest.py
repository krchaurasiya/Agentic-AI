import pytest

from backend.config import settings


@pytest.fixture(autouse=True)
def isolated_storage(tmp_path, monkeypatch):
    """Never write test runs into the real outputs/ or database."""
    monkeypatch.setattr(settings, "outputs_dir", str(tmp_path / "outputs"))
    monkeypatch.setattr(settings, "database_path", str(tmp_path / "runs.sqlite3"))
