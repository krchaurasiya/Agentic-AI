from backend.evidence import EvidenceRegistry
from backend.schemas import DecisionReport
from backend.validation import normalize, sanitize, validate_report
from fakes import good_report


def _reg(n=2):
    reg = EvidenceRegistry()
    for i in range(n):
        reg.add_source(title=f"Paper {i}", url=f"https://example.org/{i}", summary="s")
    return reg


def test_good_report_passes():
    reg = _reg()
    r = normalize(DecisionReport.model_validate(good_report(["E1", "E2"])), reg)
    v = validate_report(r, reg)
    assert v["passed"], v["issues"]


def test_unknown_citation_fails_then_is_sanitized():
    reg = _reg()
    data = good_report(["E1", "E99"])
    r = normalize(DecisionReport.model_validate(data), reg)
    assert "all cited ids exist in retrieved evidence" in [k for k, ok in validate_report(r, reg)["checks"].items() if not ok]
    r, notes = sanitize(r, reg)
    assert notes and "E99" not in " ".join(r.options[1].evidence_ids) and "E99" not in r.options[1].justification
    assert validate_report(r, reg)["checks"]["all cited ids exist in retrieved evidence"]


def test_missing_trade_offs_and_too_few_options_fail():
    reg = _reg()
    data = good_report(["E1"])
    data["options"] = data["options"][:2]
    data["options"][0]["trade_offs"] = ["short"]
    v = validate_report(normalize(DecisionReport.model_validate(data), reg), reg)
    assert not v["passed"] and any("trade-offs" in i for i in v["issues"]) and any("3 to 5" in i for i in v["issues"])


def test_mandate_and_cure_claims_flagged_but_negations_allowed():
    reg = _reg()
    data = good_report(["E1"])
    data["executive_summary"] += " Meditation cures anxiety and should be mandatory in schools."
    assert not validate_report(normalize(DecisionReport.model_validate(data), reg), reg)["checks"]["no cure / replacement / mandate claims"]
    data = good_report(["E1"])
    data["executive_summary"] += " It does not cure illness and must never be mandatory."
    assert validate_report(normalize(DecisionReport.model_validate(data), reg), reg)["checks"]["no cure / replacement / mandate claims"]


def test_no_sources_warns_and_requires_none_strength():
    reg = EvidenceRegistry()
    data = good_report([])
    v = validate_report(normalize(DecisionReport.model_validate(data), reg), reg)
    assert not v["checks"]["claims backed by evidence ids"]       # strength is not 'none'
    for o in data["options"]:
        o["evidence_strength"] = "none"
    v = validate_report(normalize(DecisionReport.model_validate(data), reg), reg)
    assert v["checks"]["claims backed by evidence ids"] and v["warnings"]
