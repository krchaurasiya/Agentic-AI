"""Whole pipeline with a scripted LLM: real Deep Agent + real MCP server + real exporters."""
import json
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage

from backend.config import settings
from backend.pipeline import new_run_id, run_pipeline
from backend.schemas import RunRequest
from fakes import ScriptedChat, call, good_report, report_json


def agent_script():
    return ScriptedChat(script=[
        call("write_todos", {"todos": [{"content": "search", "status": "in_progress"}]}, "1"),
        call("search_curated_evidence", {"query": "school mindfulness adolescents randomised"}, "2"),
        call("search_curated_evidence", {"query": "adverse effects meditation harms"}, "3"),
        call("estimate_program_cost", {"participants": 100, "sessions_per_participant": 4, "facilitator_hours_per_session": 1,
                                       "facilitator_hourly_cost": 500, "scenario_name": "pilot"}, "4"),
        AIMessage(content="## Candidate options\n1. School elective [E1]\n2. Workplace hour [E2] cost [C1]"),
    ])


async def test_full_run_with_mcp_produces_all_three_files():
    events = []
    res = await run_pipeline(new_run_id(), RunRequest(question="How can meditation be offered at scale in India?"),
                             lambda k, message="", **d: events.append((k, message, d)),
                             agent_model=agent_script(), synthesis_model=ScriptedChat(script=[report_json(["E1", "E2"])]))
    assert res["validation"]["passed"], res["validation"]
    assert res["provenance"]["mcp_servers"] == ["mindful-policy-research"]            # MCP really used
    assert res["provenance"]["tool_calls"]["search_curated_evidence"] == 2
    assert any(e["id"] == "C1" for e in res["evidence"])
    cited = {e["id"] for e in res["evidence"] if e["cited_by"]}
    assert {"E1", "E2"} <= cited
    folder = Path(settings.outputs_dir) / res["run_id"]
    assert json.loads((folder / "decision.json").read_text(encoding="utf-8"))["report"]["options"][0]["trade_offs"]
    md = (folder / "decision.md").read_text(encoding="utf-8")
    assert "## Options at a glance" in md and "**Justification**" in md and "**Trade-offs**" in md and "## Evidence sources" in md
    assert (folder / "decision.pdf").read_bytes()[:5] == b"%PDF-"
    kinds = {k for k, *_ in events}
    assert {"stage", "plan", "tool_start", "tool_end", "validation"} <= kinds


async def test_fallback_to_in_process_tools_when_mcp_disabled(monkeypatch):
    monkeypatch.setattr(settings, "use_mcp", False)
    res = await run_pipeline(new_run_id(), RunRequest(question="How can meditation be offered at scale in India?"), lambda *a, **k: None,
                             agent_model=agent_script(), synthesis_model=ScriptedChat(script=[report_json(["E1", "E2"])]))
    assert res["provenance"]["mcp_servers"] == [] and res["validation"]["passed"]


async def test_invalid_json_triggers_retry_then_succeeds():
    res = await run_pipeline(new_run_id(), RunRequest(question="How can meditation be offered at scale in India?"), lambda *a, **k: None,
                             agent_model=agent_script(),
                             synthesis_model=ScriptedChat(script=[AIMessage(content="not json at all"), report_json(["E1", "E2"])]))
    assert len(res["attempts"]) == 2 and res["attempts"][0]["parsed"] is False and res["validation"]["passed"]


async def test_hallucinated_citation_is_removed_from_final_output():
    bad = good_report(["E1", "E77"])
    res = await run_pipeline(new_run_id(), RunRequest(question="How can meditation be offered at scale in India?", max_retries=0),
                             lambda *a, **k: None, agent_model=agent_script(),
                             synthesis_model=ScriptedChat(script=[AIMessage(content=json.dumps(bad))]))
    blob = json.dumps(res["report"])
    assert "E77" not in blob
    assert any("removed automatically" in w for w in res["validation"]["warnings"])


async def test_unparseable_model_raises_actionable_error():
    from backend.pipeline import PipelineError
    with pytest.raises(PipelineError):
        await run_pipeline(new_run_id(), RunRequest(question="How can meditation be offered at scale in India?", max_retries=1),
                           lambda *a, **k: None, agent_model=agent_script(),
                           synthesis_model=ScriptedChat(script=[AIMessage(content="nope")]))
