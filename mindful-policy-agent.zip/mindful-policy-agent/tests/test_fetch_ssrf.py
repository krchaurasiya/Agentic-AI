from backend.research.sources import fetch_page


async def test_blocks_loopback_and_private_and_non_http():
    for url in ["http://127.0.0.1:8000/api/health", "http://localhost/", "http://169.254.169.254/latest/meta-data/",
                "http://10.0.0.5/", "file:///etc/passwd", "ftp://example.org/x"]:
        r = await fetch_page(url)
        assert "error" in r and "text" not in r, url
