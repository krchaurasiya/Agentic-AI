from fastapi.testclient import TestClient

from backend.main import app

client = TestClient(app)


def test_health_stack_schema():
    assert client.get("/api/health").json()["status"] == "ok"
    s = client.get("/api/stack").json()
    assert len(s["skills"]) >= 7 and {x["name"] for x in s["evidence_sources"]} >= {"Europe PMC", "PubMed (NCBI E-utilities)", "Crossref"}
    assert "trade_offs" in client.get("/api/schema").json()["decision_report"]["$defs"]["PolicyOption"]["properties"]


def test_bad_ids_and_formats_rejected():
    assert client.get("/api/runs/..%2F..%2Fetc").status_code == 404
    assert client.get("/api/runs/20260101-000000-abcd").status_code == 404
    assert client.get("/api/runs/20260101-000000-abcd/files/exe").status_code == 404


def test_request_validation():
    assert client.post("/api/runs", json={"question": "short"}).status_code == 422
