import re
import yaml

from backend.agent.harness import SKILLS_DIR
from backend.evidence import EvidenceRegistry, infer_study_type
from backend.tools.instrument import coerce_payload
from backend.tools.native import cost_math, make_local_tools, safeguard_screen


def test_every_skill_has_valid_frontmatter():
    """Deep Agents silently skips a skill whose YAML is invalid, so check them all."""
    paths = sorted(SKILLS_DIR.glob("*/SKILL.md"))
    assert len(paths) >= 7
    for p in paths:
        meta = yaml.safe_load(re.match(r"---\n(.*?)\n---", p.read_text(encoding="utf-8"), re.S).group(1))
        assert meta["name"] == p.parent.name and meta["description"], p


def test_cost_math():
    r = cost_math(10, 2, 1, 500, training_cost=1000, materials_per_participant=20, evaluation_cost=200)
    assert r["total"] == 2400  # 2 sessions x 1 h x 500 + 1000 training + 10 x 20 materials + 200 evaluation
    assert cost_math(-1, 1, 1, 1)["error"]


def test_facilitator_cost_scales_with_cohorts():
    """The original model charged the same facilitator cost for 100 and 100,000 people."""
    small = cost_math(25, 4, 1, 500)
    big = cost_math(2500, 4, 1, 500)
    assert small["cohorts"] == 1 and small["facilitator_cost"] == 2000
    assert big["cohorts"] == 100 and big["facilitator_cost"] == 200000
    assert cost_math(26, 4, 1, 500)["cohorts"] == 2


def test_cost_tool_registers_calculation_id():
    reg = EvidenceRegistry()
    tool = {t.name: t for t in make_local_tools(reg)}["estimate_program_cost"]
    out = tool.invoke({"participants": 100, "sessions_per_participant": 4, "facilitator_hours_per_session": 1,
                       "facilitator_hourly_cost": 500, "scenario_name": "pilot"})
    assert out.startswith("[C1]") and "C1" in reg.ids()


def test_check_citations_flags_unknown_ids():
    reg = EvidenceRegistry()
    reg.add_source(title="A", url="https://x.org/a")
    chk = {t.name: t for t in make_local_tools(reg)}["check_citations"]
    r = chk.invoke({"draft_text": "claim [E1] and claim [E9]"})
    assert r["unknown_ids"] == ["E9"]


def test_registry_dedupes_by_doi_and_url():
    reg = EvidenceRegistry()
    a = reg.add_source(title="T", doi="10.1/x", url="https://a")
    b = reg.add_source(title="T again", doi="10.1/X", url="https://b")
    assert a.id == b.id and len(reg.items) == 1


def test_study_type_prefers_metadata():
    assert infer_study_type(["Meta-Analysis"], "x")[1] == "publication-type metadata"
    t, basis = infer_study_type([], "A randomised trial of X")
    assert t == "randomised trial" and "verify" in basis


def test_safeguard_screen_lists_missing():
    r = safeguard_screen("A voluntary programme with referral to qualified professionals.")
    assert "voluntary / opt-out" in r["present"] and "privacy / confidentiality" in r["missing"]


def test_coerce_mcp_content_blocks():
    assert coerce_payload([{"type": "text", "text": '{"a": 1}'}]) == {"a": 1}
    assert coerce_payload('{"b": 2}') == {"b": 2}
    assert coerce_payload("plain") == "plain"
