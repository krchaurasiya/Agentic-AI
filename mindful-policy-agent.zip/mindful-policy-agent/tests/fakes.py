"""Offline stand-ins for the local LLM so the whole pipeline can be tested without Ollama."""
from __future__ import annotations

import json
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, ChatResult


class ScriptedChat(BaseChatModel):
    """Returns pre-written AIMessages in order (supports tool calls). bind_tools is a no-op."""
    script: list[Any]
    i: int = 0

    @property
    def _llm_type(self) -> str:
        return "scripted"

    def bind_tools(self, tools, **kwargs):  # noqa: ANN001
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):  # noqa: ANN001
        msg = self.script[min(self.i, len(self.script) - 1)]
        self.i += 1
        return ChatResult(generations=[ChatGeneration(message=msg)])


def call(name: str, args: dict, cid: str) -> AIMessage:
    return AIMessage(content="", tool_calls=[{"name": name, "args": args, "id": cid}])


def good_report(evidence_ids: list[str]) -> dict:
    e = evidence_ids
    def opt(i: int, name: str, ids: list[str], strength: str):
        return {"id": f"O{i}", "option": name,
                "description": f"{name} offered on a voluntary, secular basis with a non-meditation alternative.",
                "justification": f"Evidence suggests modest benefit for some outcomes {' '.join('[' + x + ']' for x in ids)}; effects are uncertain.",
                "evidence_ids": ids, "evidence_strength": strength,
                "trade_offs": ["Reach is limited to people who opt in.", "Facilitator training and quality assurance add cost."],
                "indicative_cost": "not estimated", "safeguards": ["Voluntary participation and opt-out", "Referral pathway to qualified professionals"]}
    return {
        "title": "Offering contemplative practices at scale: policy options",
        "executive_summary": "Evidence is mixed. Voluntary options with evaluation are the safest first step. Do not mandate participation.",
        "options": [opt(1, "Opt-in school elective", e[:1], "limited"), opt(2, "Workplace wellbeing hour", e[:2], "moderate"),
                    opt(3, "Community-based programme with referral", e[:1], "limited")],
        "recommendation": {"preferred_option_id": "O2", "rationale": f"Best balance of evidence and feasibility {'[' + e[0] + ']' if e else ''}.",
                           "conditions": ["Change if local pilot shows no benefit."]},
        "assumptions": ["Illustrative costs only."], "evidence_gaps": ["Little India-specific trial evidence."],
        "evaluation_plan": ["Pilot with comparison group and 6-month follow-up.", "Track uptake, retention, wellbeing and adverse experiences."],
        "limitations": ["Abstract-level evidence; structural validation does not prove accuracy."],
    }


def report_json(evidence_ids: list[str]) -> AIMessage:
    return AIMessage(content=json.dumps(good_report(evidence_ids)))
