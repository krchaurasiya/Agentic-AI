"""Quick diagnosis:  python scripts/check_setup.py"""
import importlib.util
import json
import sys
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.config import settings  # noqa: E402

print(f"Python {sys.version.split()[0]}")
for p in ["deepagents", "langchain", "langgraph", "langchain_ollama", "langchain_mcp_adapters", "mcp", "fastapi", "reportlab", "ddgs", "yaml"]:
    print(f"  {p:24}", "OK" if importlib.util.find_spec(p) else "MISSING  (run start script or pip install -r requirements.txt)")
print("UI built:", "yes" if (Path(__file__).resolve().parents[1] / "frontend/dist/index.html").is_file() else "NO (cd frontend && npm install && npm run build)")
try:
    with urllib.request.urlopen(f"{settings.ollama_base_url}/api/tags", timeout=3) as r:
        names = [m["name"] for m in json.loads(r.read()).get("models", [])]
    print("Ollama reachable. Models:", names or "none")
    print(f"{settings.ollama_model} installed:", any(n.startswith(settings.ollama_model) for n in names))
except Exception as e:  # noqa: BLE001
    print("Ollama NOT reachable:", e)
