"""Start the app and open the browser:  python run.py"""
import threading
import time
import webbrowser

import httpx
import uvicorn

from backend.config import settings


def _open_when_ready(url: str) -> None:
    for _ in range(60):
        try:
            if httpx.get(url + "/api/health", timeout=1).status_code == 200:
                webbrowser.open(url)
                return
        except Exception:  # noqa: BLE001
            time.sleep(0.5)


if __name__ == "__main__":
    url = f"http://{settings.host}:{settings.port}"
    threading.Thread(target=_open_when_ready, args=(url,), daemon=True).start()
    print(f"Mindful Policy Deep Agent -> {url}   (Ctrl+C to stop)")
    uvicorn.run("backend.main:app", host=settings.host, port=settings.port, log_level="warning")
