# Architecture

| Layer | Component | Notes |
|---|---|---|
| UI | React + CSS (Vite build in `frontend/dist`) | Polls `/api/runs/{id}` every 1.2 s for live events |
| API | FastAPI | `/api/runs`, `/api/runs/{id}`, `/api/runs/{id}/files/{json|md|pdf}`, `/api/stack`, `/api/schema`, `/api/health` |
| Queue | `backend/runs.py` | One run at a time (a local model cannot serve several); cancel supported |
| Pipeline | `backend/pipeline.py` | setup -> research -> synthesis -> validation -> export |
| Agent | `backend/agent/harness.py` | `create_deep_agent` with `CompositeBackend`: scratch files in memory, `/skills/` read-only from disk, write to `/skills/**` denied |
| Subagents | evidence-researcher, options-analyst | Own tool lists; both see the skills |
| Tools | MCP server (research) + in-process (cost, safeguards, citation check) | All wrapped by `tools/instrument.py` |
| Evidence | `backend/evidence.py` | Registry assigns E# / C# / U1 ids, dedupes by DOI/URL, infers study type (publication-type metadata first) |
| Synthesis | `backend/synthesis.py` | Ollama `format=<JSON schema>` constrains output to `DecisionReport`; lenient parser; retry with validator feedback |
| Validation | `backend/validation.py` | 11 deterministic checks; `sanitize()` strips any citation id the tools never returned |
| Export | `backend/export/` | JSON, Markdown, PDF (ReportLab) |
| Storage | SQLite (`data/runs.sqlite3`) + `outputs/` | Runs left "running" by a crash are marked interrupted on startup |

## Security notes
* Server binds to 127.0.0.1 by default; CORS only allows the Vite dev origin; run ids and file formats are whitelisted.
* The agent has no shell and no real filesystem access (in-memory scratch space only).
* Web content and search snippets are labelled untrusted in tool output and in the system prompt.
* `fetch_page` allows only public http(s) hosts, re-checks every redirect hop, caps download size, and does not parse PDFs.

## Why two stages?
Small local models are unreliable at long structured output *inside* a tool-calling loop. The agent therefore researches
freely and writes a brief; a second, schema-constrained call writes the option / justification / trade-off JSON, which is
validated and retried. This is also where citations are checked against the registry.
