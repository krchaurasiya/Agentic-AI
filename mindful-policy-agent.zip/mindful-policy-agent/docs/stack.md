# Stack, tools and evidence sources (all free; licences read from package metadata)

## Evidence the agent draws on
| Source | Gives | Key | Limits |
|---|---|---|---|
| Europe PMC REST | abstracts, publication types | none | abstract-level |
| PubMed (NCBI E-utilities) | abstracts, publication types (RCT, Meta-Analysis...) | none (optional e-mail) | ~3 req/s without an NCBI key |
| Crossref REST | confirms a paper exists, DOI | none (optional e-mail) | metadata only |
| DuckDuckGo via `ddgs` | web pages (government, WHO, NGO) | none | unofficial, may rate-limit; snippets unvetted |
| Page reader (`fetch_page`) | page text to verify claims | none | public hosts only, no PDFs |
| Curated seed pack | 8 well-known reviews/guidelines, offline | none | **unverified seeds**; add your own files |
| Your background text | context | none | never treated as evidence |

## Software
| Role | Component | Licence |
|---|---|---|
| Agent harness | LangChain Deep Agents 0.7.x | MIT |
| Graph runtime / tools | LangGraph, LangChain | MIT |
| Model connector | langchain-ollama | MIT |
| MCP | MCP Python SDK, langchain-mcp-adapters | MIT |
| Model runtime | Ollama | MIT |
| Model (default) | Qwen3 8B | Apache-2.0 |
| API | FastAPI, Uvicorn, Pydantic, httpx | MIT / BSD-3 |
| Search client | ddgs | MIT |
| PDF | ReportLab | BSD |
| UI | React, Vite | MIT |
| Fonts (bundled) | Public Sans, Source Serif 4 | SIL OFL 1.1 |
| Storage | SQLite (stdlib) | Public domain |

Ollama and Qwen3 licences are from the author's knowledge; the Python and npm licences were read from installed package metadata.

## Skills (`backend/skills`)
contemplative-policy-design, cost-and-feasibility, decision-options-format, equity-and-accessibility, evidence-review,
mental-health-safeguards, policy-evaluation.
