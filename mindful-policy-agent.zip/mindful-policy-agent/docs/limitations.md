# Limitations
Search results may be incomplete. A URL or DOI does not prove a claim. A local 8B model can misread an abstract or write
generic text. Structural validation does not prove truth. Costs depend on supplied assumptions. Meditation may not suit
everyone and can cause adverse experiences. This app is not clinical care, a crisis service, or legal advice.
