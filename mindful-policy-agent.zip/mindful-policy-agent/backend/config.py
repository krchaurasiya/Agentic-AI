"""Central settings. Every value can be overridden in .env (see .env.example)."""
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    app_name: str = "Mindful Policy Deep Agent"
    host: str = "127.0.0.1"
    port: int = 8000

    # Local LLM (Ollama, free). Any tool-calling model works; qwen3:8b is the default.
    ollama_base_url: str = "http://127.0.0.1:11434"
    ollama_model: str = "qwen3:8b"
    ollama_temperature: float = 0.0
    ollama_num_ctx: int = 16384      # Deep Agents' prompt is large; 4096 is too small.
    ollama_reasoning: bool = False   # qwen3 "thinking": slower, usually not needed here.
    ollama_keep_alive: str = "30m"

    # Agent / MCP
    use_mcp: bool = True
    mcp_config: str = "config/mcp_servers.json"
    agent_recursion_limit: int = 90
    run_timeout_seconds: int = 2400
    max_review_retries: int = 2

    # Research sources (all keyless). A contact e-mail is optional but recommended:
    # Crossref and NCBI give better rate limits to identifiable, polite clients.
    contact_email: str = ""
    request_timeout_seconds: int = 20
    max_fetch_chars: int = 6000

    # Storage
    database_path: str = "data/runs.sqlite3"
    outputs_dir: str = "outputs"

    model_config = SettingsConfigDict(env_file=str(ROOT / ".env"), extra="ignore")

    def path(self, value: str) -> Path:
        p = Path(value)
        return p if p.is_absolute() else ROOT / p


settings = Settings()
