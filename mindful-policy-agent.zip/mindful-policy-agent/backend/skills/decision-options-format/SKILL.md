---
name: decision-options-format
description: "Use before finishing research. Defines how to structure findings as decision options, each with an option, a justification grounded in evidence ids, and explicit trade-offs."
license: MIT
---
# Decision Options Format

The final report is a set of 3 to 5 distinct policy options. For each option the research brief must contain:

1. **Option** - a short name and what it is (who delivers it, for whom, how often).
2. **Justification** - why it is worth considering. Every empirical claim carries an evidence id such as [E3] taken from tool results. If no retrieved evidence supports it, say "no retrieved evidence" and label it reasoned judgement.
3. **Trade-offs** - at least two concrete things given up or risked (cost, reach, evidence quality, harms, equity, staffing, delay).
4. **Evidence strength** - strong, moderate, limited or none, and why. A single small trial is limited.

Options must be genuinely different (for example: opt-in school electives, workplace wellbeing hours, community-based programmes, self-directed digital/low-cost resources, a do-nothing or non-meditation comparator). All options are voluntary and secular, with a non-meditation alternative and a referral pathway. Never invent ids, DOIs, statistics or effect sizes.
