---
name: evidence-review
description: "Use when searching and appraising research: pick sources, record study design, population, findings and limitations, and separate trials, reviews, guidelines, opinion and philosophy."
license: MIT
---
# Evidence Review Skill

Search peer-reviewed studies and authoritative public-health sources. Record title, year, URL/DOI, study design, population, outcomes, findings and limitations. Distinguish randomized trials, observational studies, systematic reviews, guidelines and opinion. Never invent effect sizes or citations. Output an evidence table and evidence gaps.
