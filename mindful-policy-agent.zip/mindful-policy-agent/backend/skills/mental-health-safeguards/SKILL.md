---
name: mental-health-safeguards
description: "Use when checking consent, opt-out, privacy, facilitator competence, distress response, adverse experiences and referral pathways for wellbeing programmes."
license: MIT
---
# Mental Health Safeguards Skill

Check consent, voluntary participation, data minimization, confidentiality, facilitator competence, distress response, safe stopping, alternatives and referral pathways. This programme is not a diagnostic or therapeutic substitute. Avoid individualized medical advice.
