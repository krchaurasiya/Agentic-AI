---
name: contemplative-policy-design
description: "Use when turning contemplative or meditation ideas into voluntary, secular, inclusive policy options for schools, workplaces, community health and self-directed use."
license: MIT
---
# Contemplative Policy Design Skill

Treat the supplied article as philosophical context only. Translate themes into voluntary, secular and culturally adaptable options for schools, workplaces, community health and self-directed use. Include non-meditation alternatives and the right to opt out. Never mandate participation.
