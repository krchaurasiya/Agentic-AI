---
name: equity-and-accessibility
description: "Use when checking who is excluded: affordability, language, disability, neurodiversity, culture, digital access, shift work, rural access."
license: MIT
---
# Equity and Accessibility Skill

Check affordability, language, disability, neurodiversity, cultural acceptability, digital access, shift work and rural access. Include non-participants. Recommend community consultation and disaggregated evaluation. Avoid coercion and discrimination.
