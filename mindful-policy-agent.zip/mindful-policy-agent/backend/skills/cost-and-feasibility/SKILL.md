---
name: cost-and-feasibility
description: "Use when estimating programme cost or feasibility: participants, sessions, facilitators, training, materials, evaluation. Uses the estimate_program_cost tool, never invented prices."
license: MIT
---
# Cost and Feasibility Skill

Identify participants, sessions, facilitator time, training, materials, accessibility and evaluation. Label all assumptions. Use deterministic calculations. Compare pilot and scale scenarios. Separate sourced prices from illustrative estimates; never fabricate local prices.
