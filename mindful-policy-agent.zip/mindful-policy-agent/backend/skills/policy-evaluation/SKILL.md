---
name: policy-evaluation
description: "Use when designing how an option will be evaluated: theory of change, baseline, comparison, follow-up, uptake, validated measures, harms, cost and equity."
license: MIT
---
# Policy Evaluation Skill

Define theory of change, baseline, comparison design, follow-up, reach, uptake, retention, appropriate validated wellbeing measures, adverse experiences, costs, equity and implementation fidelity. Do not claim causality unless design supports it.
