"""Evidence registry: every source the agent sees gets a stable id, so the final report can only cite real items."""
from __future__ import annotations

import re
from datetime import datetime, timezone

from backend.schemas import EvidenceItem

ID_RE = re.compile(r"\b([ECU]\d{1,3})\b")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _norm_key(doi: str, url: str, title: str) -> str:
    if doi:
        return "doi:" + doi.lower().strip()
    if url:
        return "url:" + re.sub(r"^https?://(www\.)?", "", url.lower()).rstrip("/")
    return "title:" + re.sub(r"\W+", " ", title.lower()).strip()


def infer_study_type(pub_types: list[str], title: str, summary: str = "") -> tuple[str, str]:
    """Return (study_type, basis). Publication-type metadata beats keyword guessing."""
    pt = " ".join(pub_types).lower()
    for needle, label in [
        ("meta-analysis", "meta-analysis"),
        ("systematic review", "systematic review"),
        ("randomized controlled trial", "randomised controlled trial"),
        ("practice guideline", "guideline"),
        ("guideline", "guideline"),
        ("clinical trial", "clinical trial"),
        ("observational", "observational study"),
        ("review", "narrative review"),
    ]:
        if needle in pt:
            return label, "publication-type metadata"
    t = f"{title} {summary[:600]}".lower()
    for needle, label in [
        ("meta-analys", "meta-analysis"),
        ("systematic review", "systematic review"),
        ("randomi", "randomised trial"),
        ("cluster trial", "randomised trial"),
        ("guideline", "guideline"),
        ("cohort", "observational study"),
        ("cross-sectional", "observational study"),
        ("qualitative", "qualitative study"),
        ("review", "review"),
    ]:
        if needle in t:
            return label, "inferred from title/abstract keywords (verify)"
    return "unclassified", ""


class EvidenceRegistry:
    def __init__(self) -> None:
        self.items: dict[str, EvidenceItem] = {}
        self._keys: dict[str, str] = {}
        self._n_src = 0
        self._n_calc = 0

    # -- writing ---------------------------------------------------------
    def add_source(self, *, title: str, url: str = "", doi: str = "", source: str = "", published: str = "",
                   summary: str = "", limitations: str = "", pub_types: list[str] | None = None,
                   study_type: str | None = None, via: str = "", query: str = "",
                   status: str = "retrieved") -> EvidenceItem:
        key = _norm_key(doi, url, title)
        if key in self._keys:
            existing = self.items[self._keys[key]]
            if summary and len(summary) > len(existing.summary):
                existing.summary = summary
            return existing
        self._n_src += 1
        stype, basis = (study_type, "provided by source") if study_type else infer_study_type(pub_types or [], title, summary)
        item = EvidenceItem(
            id=f"E{self._n_src}", title=title.strip()[:300] or "(untitled)", url=url, doi=doi, source=source,
            published=published, summary=summary.strip()[:2500], limitations=limitations,
            study_type=stype, study_type_basis=basis, status=status, via=via, query=query,
            retrieved_at=_now(),
        )
        self.items[item.id] = item
        self._keys[key] = item.id
        return item

    def add_calculation(self, *, title: str, summary: str, via: str) -> EvidenceItem:
        self._n_calc += 1
        item = EvidenceItem(
            id=f"C{self._n_calc}", kind="calculation", title=title, summary=summary, source="local calculator",
            status="calculation", via=via, study_type="illustrative calculation",
            limitations="Based on assumptions supplied by the agent or user; not market prices.",
            retrieved_at=_now(),
        )
        self.items[item.id] = item
        return item

    def add_user_context(self, text: str) -> EvidenceItem | None:
        if not text.strip():
            return None
        item = EvidenceItem(
            id="U1", kind="user_context", title="User-supplied background text", summary=text.strip()[:1200],
            source="user", status="user-supplied", study_type="context / opinion (not evidence)",
            limitations="Philosophical or contextual material; not scientific evidence.", retrieved_at=_now(),
        )
        self.items["U1"] = item
        return item

    def mark_fetched(self, url: str, excerpt: str) -> str | None:
        key = _norm_key("", url, "")
        iid = self._keys.get(key)
        if iid:
            it = self.items[iid]
            it.status = "fetched" if it.status == "retrieved" else it.status
            if excerpt and len(excerpt) > len(it.summary):
                it.summary = excerpt[:2500]
        return iid

    # -- reading ---------------------------------------------------------
    def ids(self) -> set[str]:
        return set(self.items)

    def all(self) -> list[EvidenceItem]:
        return list(self.items.values())

    def digest(self, prefer: set[str] | None = None, max_items: int = 24, max_chars: int = 380) -> str:
        prefer = prefer or set()
        ordered = sorted(self.items.values(), key=lambda i: (i.id not in prefer, i.kind == "user_context"))
        lines = []
        for it in ordered[:max_items]:
            meta = ", ".join(x for x in [it.source, it.published[:4], it.study_type] if x)
            lines.append(f"[{it.id}] ({meta}) {it.title}\n    {it.summary[:max_chars].replace(chr(10), ' ')}")
        return "\n".join(lines) if lines else "(no evidence was retrieved)"

    def mark_cited(self, option_id: str, ids: list[str]) -> None:
        for i in ids:
            if i in self.items and option_id not in self.items[i].cited_by:
                self.items[i].cited_by.append(option_id)


def ids_in(text: str) -> set[str]:
    return set(ID_RE.findall(text or ""))
