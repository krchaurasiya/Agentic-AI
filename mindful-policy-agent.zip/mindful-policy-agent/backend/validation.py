"""Deterministic checks on the decision report. These verify STRUCTURE and TRACEABILITY, not truth."""
from __future__ import annotations

import re

from backend.evidence import ID_RE, EvidenceRegistry, ids_in
from backend.schemas import DecisionReport

NEGATIONS = ("not ", "never", "no ", "avoid", "without", "rather than", "should not", "must not", "cannot", "n't")
RISKY = [
    (re.compile(r"\bcures?\b|\bcured\b", re.I), "claims meditation cures something"),
    (re.compile(r"\breplaces?\s+(therapy|counsel+ing|treatment|medication|clinical care)", re.I), "claims it replaces clinical care"),
    (re.compile(r"\bmandatory\b|\bcompulsory\b|\bmust (attend|participate)", re.I), "proposes mandatory participation"),
]


def report_text(r: DecisionReport) -> str:
    parts = [r.title, r.executive_summary, r.recommendation.rationale, *r.recommendation.conditions,
             *r.assumptions, *r.evidence_gaps, *r.evaluation_plan, *r.limitations]
    for o in r.options:
        parts += [o.option, o.description, o.justification, o.indicative_cost, *o.trade_offs, *o.safeguards]
    return "\n".join(parts)


def normalize(r: DecisionReport, registry: EvidenceRegistry) -> DecisionReport:
    """Harmless clean-up: merge ids written in the justification text into evidence_ids; de-duplicate."""
    for o in r.options:
        merged = [i.strip() for i in o.evidence_ids] + sorted(ids_in(o.justification))
        o.evidence_ids = list(dict.fromkeys(i for i in merged if i))
        o.trade_offs = [t.strip() for t in o.trade_offs if t and t.strip()]
        o.safeguards = [s.strip() for s in o.safeguards if s and s.strip()]
    return r


def sanitize(r: DecisionReport, registry: EvidenceRegistry) -> tuple[DecisionReport, list[str]]:
    """Last line of defence: remove any citation id that was not returned by a tool. Returns notes on what was removed."""
    known, notes = registry.ids(), []

    def clean(text: str) -> str:
        def sub(m: re.Match) -> str:
            if m.group(1) in known:
                return m.group(0)
            notes.append(f"removed unknown citation {m.group(1)}")
            return "[unverified citation removed]"
        return re.sub(r"\[?\b([ECU]\d{1,3})\b\]?", sub, text)

    for o in r.options:
        for i in o.evidence_ids:
            if i not in known:
                notes.append(f"removed unknown id {i}")
        o.evidence_ids = [i for i in o.evidence_ids if i in known]
        o.justification, o.description = clean(o.justification), clean(o.description)
        o.indicative_cost = clean(o.indicative_cost)
        o.trade_offs = [clean(t) for t in o.trade_offs]
        if not o.evidence_ids and o.evidence_strength != "none":
            o.evidence_strength = "none"
            notes.append(f"{o.id}: evidence strength set to 'none' because no valid evidence id remained")
    r.executive_summary = clean(r.executive_summary)
    r.recommendation.rationale = clean(r.recommendation.rationale)
    return r, notes


def validate_report(r: DecisionReport, registry: EvidenceRegistry) -> dict:
    known = registry.ids()
    text = report_text(r)
    low = text.lower()
    checks: dict[str, tuple[bool, str]] = {}

    n = len(r.options)
    checks["3-5 distinct options"] = (3 <= n <= 5, f"found {n} options; provide 3 to 5")
    ids = [o.id for o in r.options]
    checks["unique option ids"] = (len(set(ids)) == len(ids), "option ids must be unique (O1, O2, ...)")
    checks["every option has a justification"] = (
        all(len(o.justification.strip()) >= 40 for o in r.options),
        "each option needs a justification of at least one full sentence")
    checks["every option states trade-offs"] = (
        all(len([t for t in o.trade_offs if len(t) >= 12]) >= 2 for o in r.options),
        "each option needs at least two concrete trade-offs")
    unknown = sorted({i for o in r.options for i in o.evidence_ids if i not in known} | (ids_in(text) - known))
    checks["all cited ids exist in retrieved evidence"] = (
        not unknown, f"these ids were never returned by a tool: {', '.join(unknown)}. Remove them or use ids from the evidence list")
    has_sources = any(i.startswith("E") for i in known)
    checks["claims backed by evidence ids"] = (
        all(o.evidence_ids or o.evidence_strength == "none" for o in r.options),
        "options with no evidence id must set evidence_strength to 'none' and say the justification is reasoned judgement")
    checks["recommendation points to a real option"] = (
        r.recommendation.preferred_option_id in ids, f"preferred_option_id must be one of {', '.join(ids)}")
    checks["safeguards: voluntary and referral"] = (
        any(w in low for w in ("voluntary", "opt-out", "opt out", "opt-in", "optional"))
        and any(w in low for w in ("referral", "qualified professional", "mental health professional", "counsell")),
        "mention voluntary participation / opt-out and a referral pathway to qualified professionals")
    risky = []
    for sent in re.split(r"(?<=[.!?])\s+|\n", text):
        for rx, why in RISKY:
            if rx.search(sent) and not any(neg in sent.lower() for neg in NEGATIONS):
                risky.append(why)
    checks["no cure / replacement / mandate claims"] = (not risky, "; ".join(sorted(set(risky))) or "")
    checks["evaluation plan"] = (len(r.evaluation_plan) >= 2, "give at least two concrete evaluation steps")
    checks["limitations stated"] = (len(r.limitations) >= 1, "state limitations")
    checks["executive summary"] = (len(r.executive_summary.strip()) >= 100, "executive summary should be 4-6 sentences")

    issues = [msg for ok, msg in checks.values() if not ok]
    warnings = []
    if not has_sources:
        warnings.append("No external sources were retrieved in this run: every option is reasoned judgement, not evidence-based.")
    if has_sources and not any(o.evidence_ids for o in r.options):
        warnings.append("Sources were retrieved but no option cites them.")
    if any(registry.items[i].status == "seed-unverified" for i in known if i in registry.items):
        warnings.append("Some evidence comes from the offline seed pack and is unverified; open the links to confirm.")
    passed_n = sum(1 for ok, _ in checks.values() if ok)
    return {
        "passed": not issues, "score": round(100 * passed_n / len(checks)), "issues": issues, "warnings": warnings,
        "checks": {k: ok for k, (ok, _) in checks.items()},
        "note": "These checks confirm structure and that cited ids exist. They do not prove the claims are true or clinically safe.",
    }
