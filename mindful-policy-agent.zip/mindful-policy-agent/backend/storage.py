"""SQLite run history (stdlib, no server needed)."""
from __future__ import annotations

import json
import sqlite3
from contextlib import closing

from backend.config import settings


def _db() -> sqlite3.Connection:
    p = settings.path(settings.database_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(p)
    c.execute("""CREATE TABLE IF NOT EXISTS runs (
        id TEXT PRIMARY KEY, created_at TEXT, status TEXT, question TEXT, request_json TEXT,
        result_json TEXT, events_json TEXT, error TEXT)""")
    return c


def save_run(run_id: str, created_at: str, status: str, request: dict, result: dict | None, events: list, error: str = "") -> None:
    with closing(_db()) as c, c:
        c.execute("INSERT OR REPLACE INTO runs VALUES (?,?,?,?,?,?,?,?)",
                  (run_id, created_at, status, request.get("question", ""), json.dumps(request, ensure_ascii=False),
                   json.dumps(result, ensure_ascii=False) if result else None, json.dumps(events, ensure_ascii=False), error))


def list_runs(limit: int = 30) -> list[dict]:
    with closing(_db()) as c:
        rows = c.execute("SELECT id, created_at, status, question, result_json FROM runs ORDER BY created_at DESC LIMIT ?",
                         (max(1, min(limit, 200)),)).fetchall()
    out = []
    for rid, created, status, q, rj in rows:
        score = None
        if rj:
            try:
                score = json.loads(rj)["validation"]["score"]
            except Exception:  # noqa: BLE001
                pass
        out.append({"id": rid, "created_at": created, "status": status, "question": q, "score": score})
    return out


def get_run(run_id: str) -> dict | None:
    with closing(_db()) as c:
        r = c.execute("SELECT id, created_at, status, request_json, result_json, events_json, error FROM runs WHERE id=?", (run_id,)).fetchone()
    if not r:
        return None
    return {"id": r[0], "created_at": r[1], "status": r[2], "request": json.loads(r[3]),
            "result": json.loads(r[4]) if r[4] else None, "events": json.loads(r[5] or "[]"), "error": r[6] or ""}


def delete_run(run_id: str) -> None:
    with closing(_db()) as c, c:
        c.execute("DELETE FROM runs WHERE id=?", (run_id,))


def mark_interrupted() -> None:
    """Runs left 'running' by a previous server process can never finish."""
    with closing(_db()) as c, c:
        c.execute("UPDATE runs SET status='interrupted', error='Server restarted while this run was in progress.' WHERE status='running'")
