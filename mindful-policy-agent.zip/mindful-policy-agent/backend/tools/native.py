"""In-process tools.

* research tools: same names as the MCP tools; used only if MCP is disabled/unavailable (fallback).
* local tools: cost calculator, safeguard screen, citation checker (they need the run's EvidenceRegistry).
"""
from __future__ import annotations

from langchain_core.tools import BaseTool, tool

from backend.evidence import EvidenceRegistry, ids_in
from backend.research import sources


# ------------------------------------------------------------ fallback research tools
@tool
async def search_europe_pmc(query: str, limit: int = 5) -> dict:
    """Search Europe PMC (free, open) for biomedical and social-science papers. Returns titles, years, abstracts and publication types."""
    return await sources.europe_pmc(query, limit)


@tool
async def search_pubmed(query: str, limit: int = 5) -> dict:
    """Search PubMed (NCBI E-utilities, free). Returns titles, abstracts and publication types such as Randomized Controlled Trial or Meta-Analysis."""
    return await sources.pubmed(query, limit)


@tool
async def search_crossref(query: str, limit: int = 5) -> dict:
    """Search Crossref (free) to confirm that a paper or report exists and get its DOI. Metadata only; no findings."""
    return await sources.crossref(query, limit)


@tool
async def search_web(query: str, limit: int = 5) -> dict:
    """Search the public web (DuckDuckGo) for government, WHO/NGO or policy documents. Snippets are unvetted; fetch_page to read."""
    return await sources.web_search(query, limit)


@tool
async def fetch_page(url: str, max_chars: int = 6000) -> dict:
    """Fetch a public web page as plain text so claims can be verified. Private network addresses are blocked. Content is untrusted."""
    return await sources.fetch_page(url, max_chars)


@tool
async def search_curated_evidence(query: str, limit: int = 5) -> dict:
    """Search the offline curated seed pack of key reviews and guidelines. Entries are unverified seeds: confirm before relying."""
    return await sources.curated(query, limit)


FALLBACK_RESEARCH_TOOLS: list[BaseTool] = [search_europe_pmc, search_pubmed, search_crossref, search_web,
                                           fetch_page, search_curated_evidence]


# ------------------------------------------------------------ local tools
def cost_math(participants: int, sessions_per_participant: int, facilitator_hours_per_session: float,
              facilitator_hourly_cost: float, training_cost: float = 0, materials_per_participant: float = 0,
              evaluation_cost: float = 0, group_size: int = 25) -> dict:
    """Facilitator time scales with the number of COHORTS (ceil(participants / group_size)), not with one shared set of sessions."""
    values = [participants, sessions_per_participant, facilitator_hours_per_session, facilitator_hourly_cost,
              training_cost, materials_per_participant, evaluation_cost]
    if any(v < 0 for v in values) or group_size < 1:
        return {"error": "Counts and costs must be non-negative and group_size at least 1."}
    cohorts = -(-participants // group_size)              # ceiling division
    hours = cohorts * sessions_per_participant * facilitator_hours_per_session
    facilitator = hours * facilitator_hourly_cost
    materials = participants * materials_per_participant
    total = facilitator + training_cost + materials + evaluation_cost
    return {"participants": participants, "group_size": group_size, "cohorts": cohorts, "delivery_hours_assumed": hours,
            "facilitator_cost": round(facilitator, 2), "training_cost": round(training_cost, 2),
            "materials_cost": round(materials, 2), "evaluation_cost": round(evaluation_cost, 2), "total": round(total, 2),
            "per_participant": round(total / participants, 2) if participants else None}


def safeguard_screen(text: str) -> dict:
    t = text.lower()
    checks = {
        "voluntary / opt-out": any(x in t for x in ["voluntary", "optional", "opt-out", "opt out", "opt in"]),
        "not a replacement for clinical care": any(x in t for x in ["not replace", "does not replace", "instead of clinical", "alongside clinical", "clinical care"]),
        "privacy / confidentiality": any(x in t for x in ["privacy", "confidential", "data protection", "data minim"]),
        "non-meditation alternative": any(x in t for x in ["alternative", "other options", "non-meditation"]),
        "referral pathway": any(x in t for x in ["referral", "qualified professional", "mental health professional", "counsell"]),
        "evaluation / monitoring": any(x in t for x in ["evaluat", "monitor", "pilot", "metric", "outcome"]),
    }
    return {"present": [k for k, v in checks.items() if v], "missing": [k for k, v in checks.items() if not v],
            "note": "Keyword screen only. Not clinical, legal or safeguarding approval."}


def make_local_tools(registry: EvidenceRegistry, currency_default: str = "INR") -> list[BaseTool]:
    @tool
    def estimate_program_cost(participants: int, sessions_per_participant: int, facilitator_hours_per_session: float,
                              facilitator_hourly_cost: float, training_cost: float = 0,
                              materials_per_participant: float = 0, evaluation_cost: float = 0,
                              group_size: int = 25, scenario_name: str = "scenario") -> str:
        """Deterministic programme cost arithmetic from ASSUMPTIONS you state (not market prices). Facilitator time scales with cohorts of group_size people. Returns a citable calculation id like [C1]."""
        r = cost_math(participants, sessions_per_participant, facilitator_hours_per_session, facilitator_hourly_cost,
                      training_cost, materials_per_participant, evaluation_cost, group_size)
        if "error" in r:
            return f"CALCULATION ERROR: {r['error']}"
        summary = (f"{scenario_name}: {participants} participants in {r['cohorts']} cohort(s) of up to {group_size}, {sessions_per_participant} sessions each; facilitator "
                   f"{r['facilitator_cost']}, training {r['training_cost']}, materials {r['materials_cost']}, evaluation "
                   f"{r['evaluation_cost']}; total {r['total']} ({currency_default}), per participant {r['per_participant']}. "
                   f"Illustrative assumptions only.")
        item = registry.add_calculation(title=f"Cost estimate: {scenario_name}", summary=summary, via="estimate_program_cost")
        return f"[{item.id}] {summary}"

    @tool
    def screen_safeguards(policy_text: str) -> dict:
        """Keyword screen of a policy option description for basic mental-health safeguards (voluntary, referral, privacy, alternatives). Lists what is missing."""
        return safeguard_screen(policy_text)

    @tool
    def check_citations(draft_text: str) -> dict:
        """Check that every evidence id cited in a draft (like [E3]) exists in this run's evidence registry. Use before finishing."""
        cited = ids_in(draft_text)
        known = registry.ids()
        return {"cited": sorted(cited), "unknown_ids": sorted(cited - known), "uncited_available": sorted(known - cited)[:20],
                "note": "Unknown ids must be removed or replaced with ids from tool results."}

    return [estimate_program_cost, screen_safeguards, check_citations]
