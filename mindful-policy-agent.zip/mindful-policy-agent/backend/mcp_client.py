"""Connect to the MCP servers listed in config/mcp_servers.json and expose their tools to the agent."""
from __future__ import annotations

import json
import os
import sys
from contextlib import AsyncExitStack, asynccontextmanager
from typing import AsyncIterator, Callable

from langchain_core.tools import BaseTool

from backend.config import ROOT, settings


def load_server_config() -> dict[str, dict]:
    path = settings.path(settings.mcp_config)
    try:
        raw = json.loads(path.read_text(encoding="utf-8")).get("mcpServers", {})
    except Exception:  # noqa: BLE001
        return {}
    out: dict[str, dict] = {}
    for name, cfg in raw.items():
        if cfg.get("disabled"):
            continue
        conn = {k: v for k, v in cfg.items() if k not in ("disabled", "description")}
        conn["command"] = sys.executable if conn.get("command") == "${PYTHON}" else conn.get("command")
        conn.setdefault("transport", "stdio")
        if conn["transport"] == "stdio":
            conn.setdefault("cwd", str(ROOT))
            env = dict(os.environ)
            env["PYTHONPATH"] = str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")
            env["CONTACT_EMAIL"] = settings.contact_email
            conn.setdefault("env", env)
        out[name] = conn
    return out


def describe_servers() -> list[dict]:
    """For the UI 'stack' page: all servers including disabled ones."""
    path = settings.path(settings.mcp_config)
    try:
        raw = json.loads(path.read_text(encoding="utf-8")).get("mcpServers", {})
    except Exception:  # noqa: BLE001
        return []
    return [{"name": n, "enabled": not c.get("disabled", False), "transport": c.get("transport", "stdio"),
             "description": c.get("description", "")} for n, c in raw.items()]


@asynccontextmanager
async def mcp_tools(emit: Callable[..., None]) -> AsyncIterator[tuple[list[BaseTool], list[str]]]:
    """Yield (tools, connected_server_names). Yields ([], []) if MCP is off or every server fails."""
    if not settings.use_mcp:
        emit("info", message="MCP disabled in settings; using in-process research tools.")
        yield [], []
        return
    configs = load_server_config()
    if not configs:
        emit("warn", message="No MCP servers configured; using in-process research tools.")
        yield [], []
        return
    from langchain_mcp_adapters.client import MultiServerMCPClient
    from langchain_mcp_adapters.tools import load_mcp_tools

    client = MultiServerMCPClient(configs)
    tools: list[BaseTool] = []
    names: list[str] = []
    async with AsyncExitStack() as stack:
        for name in configs:
            try:
                session = await stack.enter_async_context(client.session(name))
                loaded = await load_mcp_tools(session, server_name=name)
                tools.extend(loaded)
                names.append(name)
                emit("info", message=f"MCP server '{name}' connected: {', '.join(t.name for t in loaded)}")
            except Exception as exc:  # noqa: BLE001
                emit("warn", message=f"MCP server '{name}' unavailable ({type(exc).__name__}); falling back where possible.")
        yield tools, names
