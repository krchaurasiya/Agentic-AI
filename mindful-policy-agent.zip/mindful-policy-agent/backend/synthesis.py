"""Stage 2: turn the research brief + evidence registry into the structured decision report (option / justification / trade-off)."""
from __future__ import annotations

import json
import re
from typing import Callable

from langchain_core.language_models import BaseChatModel
from pydantic import ValidationError

from backend.evidence import EvidenceRegistry, ids_in
from backend.schemas import DecisionReport, RunRequest
from backend.validation import normalize, sanitize, validate_report

SYSTEM = """You write the final decision report for a public-policy question. Output ONLY a JSON object that matches the schema.
Format: 3 to 5 distinct policy options. For EACH option give: option (name), description, justification, evidence_ids, evidence_strength, trade_offs (at least two), indicative_cost, safeguards.
Rules:
- Cite evidence only by ids from the EVIDENCE LIST (for example [E3]); put the same ids in evidence_ids. If no listed evidence supports an option, leave evidence_ids empty, set evidence_strength to "none" and write in the justification that it is reasoned judgement.
- Do not invent sources, numbers, effect sizes or costs. Cost figures may only come from calculation ids like [C1]; otherwise write "not estimated".
- Options must be voluntary and secular, with a non-meditation alternative and a referral pathway to qualified professionals. Never mandatory. Never claim cures or replacement of clinical care.
- Background text supplied by the user is context, not evidence.
- Be honest about weak evidence: one small or non-replicated study is "limited".
- Include recommendation, assumptions, evidence_gaps, evaluation_plan (concrete) and limitations."""


def extract_json(text: str) -> str:
    text = re.sub(r"<think>.*?</think>", "", text or "", flags=re.S)
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.M)
    a, b = text.find("{"), text.rfind("}")
    return text[a:b + 1] if a != -1 and b > a else text


def parse_report(text: str) -> DecisionReport:
    return DecisionReport.model_validate_json(extract_json(text))


def build_prompt(req: RunRequest, brief: str, registry: EvidenceRegistry, feedback: str) -> str:
    prefer = ids_in(brief)
    return (
        f"POLICY QUESTION: {req.question}\nGEOGRAPHY: {req.geography}\nTARGET POPULATION: {req.population}\n"
        f"BUDGET CONTEXT: {req.budget_context}\n"
        f"USER BACKGROUND (context only, not evidence): {req.context[:1500] or 'none'}\n\n"
        f"EVIDENCE LIST (the only citable ids):\n{registry.digest(prefer)}\n\n"
        f"RESEARCH BRIEF FROM THE RESEARCH AGENT:\n{brief[:7000] or '(none)'}\n"
        f"{feedback}\n\nReturn the JSON decision report now."
    )


async def synthesize(model: BaseChatModel, req: RunRequest, brief: str, registry: EvidenceRegistry,
                     emit: Callable[..., None], max_retries: int) -> tuple[DecisionReport | None, dict, list[dict], list[str]]:
    attempts: list[dict] = []
    best: tuple[int, DecisionReport, dict] | None = None
    feedback = ""
    for n in range(1, max_retries + 2):
        emit("synthesis", message=f"Drafting decision report (attempt {n} of {max_retries + 1})", attempt=n)
        try:
            msg = await model.ainvoke([("system", SYSTEM), ("human", build_prompt(req, brief, registry, feedback))])
            content = msg.content if isinstance(msg.content, str) else "".join(
                c.get("text", "") if isinstance(c, dict) else str(c) for c in msg.content)
            report = normalize(parse_report(content), registry)
        except (ValidationError, ValueError) as exc:
            err = re.sub(r"\s+", " ", str(exc))[:300]
            attempts.append({"attempt": n, "parsed": False, "error": err})
            emit("warn", message=f"Attempt {n}: model output did not match the schema; retrying." if n <= max_retries else f"Attempt {n}: output did not match the schema.")
            feedback = f"\n\nYOUR PREVIOUS OUTPUT WAS INVALID ({err}). Return one valid JSON object matching the schema."
            continue
        v = validate_report(report, registry)
        attempts.append({"attempt": n, "parsed": True, "score": v["score"], "issues": v["issues"]})
        emit("validation", message=f"Validation score {v['score']}/100" + ("" if v["passed"] else f" - {len(v['issues'])} issue(s)"),
             score=v["score"], issues=v["issues"])
        if best is None or v["score"] > best[0]:
            best = (v["score"], report, v)
        if v["passed"]:
            break
        feedback = "\n\nVALIDATION FEEDBACK - fix all of these and keep everything else:\n- " + "\n- ".join(v["issues"])
    if best is None:
        return None, {"passed": False, "score": 0, "issues": ["model never produced a parseable report"], "warnings": [], "checks": {}}, attempts, []
    _, report, _ = best
    report, notes = sanitize(report, registry)       # never ship a citation the tools did not return
    final = validate_report(report, registry)
    if notes:
        final["warnings"].append("Unverified citations were removed automatically: " + "; ".join(sorted(set(notes))[:5]))
    for o in report.options:
        registry.mark_cited(o.id, o.evidence_ids)
    return report, final, attempts, notes
