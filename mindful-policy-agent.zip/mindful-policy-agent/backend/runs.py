"""In-memory run manager: one run at a time (a local model cannot serve several), events kept for live polling."""
from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from backend import storage
from backend.pipeline import PipelineError, new_run_id, run_pipeline
from backend.schemas import RunRequest


@dataclass
class RunState:
    id: str
    request: RunRequest
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat(timespec="seconds"))
    status: str = "queued"          # queued | running | done | failed | cancelled
    events: list[dict] = field(default_factory=list)
    result: dict | None = None
    error: str = ""
    task: asyncio.Task | None = None

    def emit(self, kind: str, message: str = "", **data: Any) -> None:
        self.events.append({"i": len(self.events), "t": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                            "type": kind, "message": message, "data": json.loads(json.dumps(data, default=str))})


class RunManager:
    def __init__(self) -> None:
        self.runs: dict[str, RunState] = {}
        self._gate = asyncio.Semaphore(1)

    def start(self, req: RunRequest) -> RunState:
        state = RunState(id=new_run_id(), request=req)
        self.runs[state.id] = state
        storage.save_run(state.id, state.created_at, state.status, req.model_dump(), None, [])
        state.task = asyncio.create_task(self._execute(state))
        return state

    async def _execute(self, s: RunState) -> None:
        try:
            if self._gate.locked():
                s.emit("info", "Waiting for the previous run to finish")
            async with self._gate:
                s.status = "running"
                s.emit("info", "Run started")
                s.result = await run_pipeline(s.id, s.request, s.emit)
                s.status = "done"
                s.emit("done", "Decision report ready")
        except asyncio.CancelledError:
            s.status, s.error = "cancelled", "Cancelled by user."
            s.emit("error", s.error)
        except PipelineError as exc:
            s.status, s.error = "failed", str(exc)
            s.emit("error", s.error)
        except Exception as exc:  # noqa: BLE001
            s.status, s.error = "failed", f"Unexpected error: {type(exc).__name__}: {exc}"
            s.emit("error", s.error)
        finally:
            storage.save_run(s.id, s.created_at, s.status, s.request.model_dump(), s.result, s.events, s.error)

    def cancel(self, run_id: str) -> bool:
        s = self.runs.get(run_id)
        if s and s.task and not s.task.done():
            s.task.cancel()
            return True
        return False


manager = RunManager()
