"""Plain-language catalogue of everything the agent is built from. Served to the UI and mirrored in docs/stack.md.
Licences for Python packages were checked against installed package metadata."""
from __future__ import annotations

import re
from importlib import metadata

import yaml  # installed with langchain/deepagents dependencies (PyYAML)

from backend.agent.harness import SKILLS_DIR
from backend.config import settings
from backend.mcp_client import describe_servers


def _ver(pkg: str) -> str:
    if not pkg:
        return ""
    try:
        return metadata.version(pkg)
    except metadata.PackageNotFoundError:
        return ""


def skills() -> list[dict]:
    out = []
    for p in sorted(SKILLS_DIR.glob("*/SKILL.md")):
        m = re.match(r"---\n(.*?)\n---", p.read_text(encoding="utf-8"), re.S)
        meta = yaml.safe_load(m.group(1)) if m else {}
        out.append({"name": meta.get("name", p.parent.name), "description": meta.get("description", "")})
    return out


EVIDENCE_SOURCES = [
    {"name": "Europe PMC", "kind": "Scholarly literature", "gives": "Titles, abstracts, publication types (review, trial...) for biomedical and social-science papers.",
     "key": "None", "limits": "Abstract-level. Coverage is strongest for biomedicine.", "url": "https://europepmc.org/RestfulWebService", "tool": "search_europe_pmc"},
    {"name": "PubMed (NCBI E-utilities)", "kind": "Scholarly literature", "gives": "Abstracts and official publication types such as Randomized Controlled Trial and Meta-Analysis.",
     "key": "None (optional e-mail via CONTACT_EMAIL)", "limits": "About 3 requests per second without an NCBI key. Abstract-level.", "url": "https://www.ncbi.nlm.nih.gov/books/NBK25497/", "tool": "search_pubmed"},
    {"name": "Crossref", "kind": "Bibliographic metadata", "gives": "Confirms a paper exists and returns its DOI.",
     "key": "None (optional e-mail for the polite pool)", "limits": "Metadata only. No findings, no quality signal.", "url": "https://www.crossref.org/documentation/retrieve-metadata/rest-api/", "tool": "search_crossref"},
    {"name": "DuckDuckGo web search", "kind": "Web", "gives": "Government, WHO and NGO documents and other pages.",
     "key": "None", "limits": "Unofficial access via the ddgs library; may be rate-limited. Snippets are unvetted.", "url": "https://duckduckgo.com", "tool": "search_web"},
    {"name": "Page reader", "kind": "Web", "gives": "Reads a public page as plain text to verify a claim.",
     "key": "None", "limits": "Private network addresses blocked; no PDF parsing; content treated as untrusted.", "url": "", "tool": "fetch_page"},
    {"name": "Curated seed pack", "kind": "Offline fallback", "gives": "A few well-known reviews and guidelines, for when live sources are unreachable.",
     "key": "None", "limits": "UNVERIFIED seeds written from author knowledge; confirm each link. Add your own reviewed entries in data/curated_evidence/.", "url": "", "tool": "search_curated_evidence"},
    {"name": "Your background text", "kind": "Context", "gives": "Essays or notes you paste in.", "key": "None",
     "limits": "Treated as context or philosophy, never as scientific evidence.", "url": "", "tool": ""},
]

TOOLS = [
    {"name": "search_europe_pmc / search_pubmed / search_crossref / search_web / fetch_page / search_curated_evidence", "where": "MCP server 'mindful-policy-research' (stdio)",
     "does": "Read-only research. Each result is given an evidence id (E1, E2...)."},
    {"name": "estimate_program_cost", "where": "In-process", "does": "Deterministic cost arithmetic from stated assumptions. Returns a calculation id (C1...)."},
    {"name": "screen_safeguards", "where": "In-process", "does": "Keyword screen for voluntary participation, referral, privacy and alternatives."},
    {"name": "check_citations", "where": "In-process", "does": "Checks that every cited id exists in this run's evidence registry."},
    {"name": "write_todos, read_file, write_file, ls, grep, task", "where": "Deep Agents harness (built in)", "does": "Planning, a private in-memory scratch filesystem, and subagent delegation. Skills are mounted read-only."},
]


def stack() -> dict:
    deps = lambda rows: [{"name": n, "version": _ver(p), "license": lic, "role": role, "cost": "Free"} for n, p, lic, role in rows]  # noqa: E731
    return {
        "model": {"name": settings.ollama_model, "runtime": "Ollama (local)", "note": "Runs on your machine. Only search keywords leave it, when research tools run."},
        "components": {
            "Agent framework and harness": deps([
                ("LangChain Deep Agents", "deepagents", "MIT", "Agent harness: planning, subagents, virtual filesystem, skills"),
                ("LangGraph", "langgraph", "MIT", "Runtime for the agent graph and streaming"),
                ("LangChain", "langchain", "MIT", "Tool and model abstractions"),
                ("langchain-ollama", "langchain-ollama", "MIT", "Connects the agent to the local Ollama model")]),
            "MCP": deps([
                ("MCP Python SDK", "mcp", "MIT", "Builds the research MCP server"),
                ("langchain-mcp-adapters", "langchain-mcp-adapters", "MIT", "Loads MCP tools into the agent")]),
            "Service and exports": deps([
                ("FastAPI", "fastapi", "MIT", "HTTP API"), ("Uvicorn", "uvicorn", "BSD-3-Clause", "Web server"),
                ("Pydantic", "pydantic", "MIT", "Schemas and validation"), ("httpx", "httpx", "BSD-3-Clause", "HTTP client"),
                ("ddgs", "ddgs", "MIT", "DuckDuckGo search client"), ("ReportLab", "reportlab", "BSD", "PDF export"),
                ("SQLite (Python standard library)", "", "Public domain", "Run history")]),
            "Interface (pre-built into frontend/dist)": [
                {"name": "React", "version": "", "license": "MIT", "role": "UI", "cost": "Free"},
                {"name": "Vite", "version": "", "license": "MIT", "role": "Build tool", "cost": "Free"},
                {"name": "Public Sans and Source Serif 4 (Fontsource)", "version": "", "license": "SIL OFL 1.1", "role": "Typefaces, bundled locally", "cost": "Free"}],
            "Model": [
                {"name": "Ollama", "version": "", "license": "MIT", "role": "Local model runtime", "cost": "Free"},
                {"name": "Qwen3 8B (default)", "version": "", "license": "Apache-2.0", "role": "Local language model; any tool-calling Ollama model can replace it", "cost": "Free"}],
        },
        "mcp_servers": describe_servers(),
        "tools": TOOLS,
        "skills": skills(),
        "evidence_sources": EVIDENCE_SOURCES,
        "subagents": [
            {"name": "evidence-researcher", "does": "Searches all sources, reads key pages, returns citable evidence with study design and limits."},
            {"name": "options-analyst", "does": "Costs options, screens safeguards, lists trade-offs."}],
    }
