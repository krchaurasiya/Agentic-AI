"""PDF export with ReportLab (pure Python, BSD licence, no system libraries needed)."""
from __future__ import annotations

from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (CondPageBreak, KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

INK, TEAL, TEAL_BG = colors.HexColor("#1B2B3A"), colors.HexColor("#1F6F6B"), colors.HexColor("#E4F1EF")
AMBER, AMBER_BG = colors.HexColor("#8F5309"), colors.HexColor("#FBEFD9")
MUTED, RULE, WARN_BG = colors.HexColor("#5B6B7A"), colors.HexColor("#C9D3DA"), colors.HexColor("#F7E7E3")
REPLACE = {"→": "->", "←": "<-", "≥": ">=", "≤": "<=", "−": "-", "×": "x", "✓": "ok", "’": "'", "‘": "'", "“": '"', "”": '"'}


def safe(text: Any) -> str:
    """Escape for ReportLab markup and keep to characters the built-in Helvetica (cp1252) can draw."""
    t = str(text or "")
    for a, b in REPLACE.items():
        t = t.replace(a, b)
    return escape(t.encode("cp1252", "replace").decode("cp1252"))


def clip(text: str, n: int) -> str:
    """Shorten at a word boundary with an ellipsis."""
    t = " ".join(str(text or "").split())
    return t if len(t) <= n else t[:n].rsplit(" ", 1)[0].rstrip(" ,;:-") + "..."


def _styles() -> dict[str, ParagraphStyle]:
    base = getSampleStyleSheet()["Normal"]
    mk = lambda name, **kw: ParagraphStyle(name, parent=base, fontName=kw.pop("font", "Helvetica"), **kw)  # noqa: E731
    return {
        "title": mk("t", font="Helvetica-Bold", fontSize=20, leading=24, textColor=INK, spaceAfter=4),
        "meta": mk("m", fontSize=8.5, leading=12, textColor=MUTED, spaceAfter=8),
        "h1": mk("h1", font="Helvetica-Bold", fontSize=13, leading=16, textColor=INK, spaceBefore=14, spaceAfter=5),
        "h2": mk("h2", font="Helvetica-Bold", fontSize=11, leading=14, textColor=INK, spaceBefore=10, spaceAfter=3),
        "body": mk("b", fontSize=9.5, leading=13.5, alignment=TA_LEFT, spaceAfter=4),
        "small": mk("s", fontSize=8, leading=10.5, textColor=MUTED),
        "cell": mk("c", fontSize=8.5, leading=11),
        "cellb": mk("cb", font="Helvetica-Bold", fontSize=8.5, leading=11),
        "tj": mk("tj", font="Helvetica-Bold", fontSize=8.5, leading=11, textColor=TEAL),
        "tt": mk("tt", font="Helvetica-Bold", fontSize=8.5, leading=11, textColor=AMBER),
    }


def _footer(canvas, doc) -> None:  # noqa: ANN001
    canvas.saveState()
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(MUTED)
    canvas.drawString(18 * mm, 10 * mm, "Mindful Policy Deep Agent - policy research aid, not clinical or legal advice")
    canvas.drawRightString(A4[0] - 18 * mm, 10 * mm, f"Page {doc.page}")
    canvas.restoreState()


def build_pdf(result: dict[str, Any], path: Path) -> None:
    S = _styles()
    r, ev, val, prov = result["report"], result["evidence"], result["validation"], result["provenance"]
    ev_by_id = {e["id"]: e for e in ev}
    opts = r["options"]
    name_of = {o["id"]: o["option"] for o in opts}
    W = A4[0] - 36 * mm
    P = lambda t, s="body": Paragraph(safe(t), S[s])  # noqa: E731
    story: list = [P(r["title"], "title"),
                   P(f"Question: {result['request']['question']}", "meta"),
                   P(f"Run {result['run_id']} | {result['created_at'][:16].replace('T', ' ')} UTC | model {prov['model']} | "
                     f"structural validation {val['score']}/100 ({'passed' if val['passed'] else 'review needed'})", "meta")]

    notes = val.get("warnings", []) + ([f"Unresolved checks: {'; '.join(val['issues'])}"] if val.get("issues") else [])
    if notes:
        t = Table([[Paragraph("<b>Read before relying on this report</b><br/>" + "<br/>".join("- " + safe(n) for n in notes), S["cell"])]], colWidths=[W])
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), WARN_BG), ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#B3321E")),
                               ("LEFTPADDING", (0, 0), (-1, -1), 8), ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
        story += [t, Spacer(1, 6)]

    rec = r["recommendation"]
    story += [P("Executive summary", "h1"), P(r["executive_summary"]),
              P("Recommendation", "h1"),
              P(f"Preferred first option: {rec['preferred_option_id']} - {name_of.get(rec['preferred_option_id'], '?')}. {rec['rationale']}")]
    if rec.get("conditions"):
        story += [P("This changes if: " + "; ".join(rec["conditions"]), "small")]

    # at-a-glance
    story += [P("Options at a glance", "h1")]
    rows = [[P("Option", "cellb"), P("Justification", "tj"), P("Main trade-off", "tt"), P("Evidence", "cellb")]]
    for o in opts:
        rows.append([P(f"{o['id']}  {o['option']}", "cellb"), P(o["justification"], "cell"),
                     P(o["trade_offs"][0] if o["trade_offs"] else "-", "cell"), P(o["evidence_strength"], "cell")])
    t = Table(rows, colWidths=[W * .2, W * .38, W * .3, W * .12], repeatRows=1)
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.4, RULE),
                           ("BACKGROUND", (1, 0), (1, 0), TEAL_BG), ("BACKGROUND", (2, 0), (2, 0), AMBER_BG),
                           ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    story += [t, P("Option details", "h1")]

    # one balance table per option
    for o in opts:
        cites = "; ".join(f"[{i}] {clip(ev_by_id[i]['title'], 62)}" for i in o["evidence_ids"] if i in ev_by_id)
        just = [Paragraph("JUSTIFICATION", S["tj"]), Spacer(1, 2), P(o["justification"], "cell")]
        if cites:
            just += [Spacer(1, 3), P("Evidence: " + cites, "small")]
        trade = [Paragraph("TRADE-OFFS", S["tt"]), Spacer(1, 2)] + [P("- " + x, "cell") for x in o["trade_offs"]]
        bal = Table([[just, trade]], colWidths=[W * .52, W * .48])
        bal.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BACKGROUND", (0, 0), (0, 0), TEAL_BG), ("BACKGROUND", (1, 0), (1, 0), AMBER_BG),
                                 ("LINEBEFORE", (1, 0), (1, 0), 0.8, INK), ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                                 ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
        block = [P(f"{o['id']}  {o['option']}", "h2"), P(f"Evidence strength: {o['evidence_strength']}", "small"), P(o["description"]), bal]
        if o.get("indicative_cost"):
            block.append(P("Indicative cost: " + o["indicative_cost"], "small"))
        if o.get("safeguards"):
            block.append(P("Safeguards: " + "; ".join(o["safeguards"]), "small"))
        story += [KeepTogether(block), Spacer(1, 8)]

    for head, key in [("Assumptions", "assumptions"), ("Evidence gaps", "evidence_gaps"),
                      ("Evaluation plan", "evaluation_plan"), ("Limitations", "limitations")]:
        if r.get(key):
            story += [P(head, "h1")] + [P("- " + x) for x in r[key]]

    # evidence
    story += [CondPageBreak(70 * mm), P("Evidence sources", "h1"),
              P("Every source below was returned by a tool during this run. Status shows how far it was checked: "
                "retrieved = abstract or snippet only; fetched = page read; seed-unverified = offline pack, confirm before use.", "small"), Spacer(1, 4)]
    rows = [[P(h, "cellb") for h in ("ID", "Source", "Year", "Type", "Status", "Cited by")]]
    for e in ev:
        title = safe(clip(e["title"], 120))
        link = f"<br/><link href=\"{escape(e['url'])}\" color=\"#1F6F6B\">{safe(e['url'][:70])}</link>" if e.get("url") else ""
        rows.append([P(e["id"], "cellb"), Paragraph(f"{title}<br/><font size=7 color='#5B6B7A'>{safe(e.get('source', ''))}</font>{link}", S["cell"]),
                     P((e.get("published") or "")[:4], "cell"), P(e.get("study_type", ""), "cell"), P(e["status"], "cell"), P(", ".join(e.get("cited_by", [])) or "-", "cell")])
    t = Table(rows, colWidths=[W * .07, W * .38, W * .07, W * .17, W * .19, W * .12], repeatRows=1)
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.4, RULE),
                           ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#EDF1F2"))]))
    story += [t, P("Method and provenance", "h1"),
              P(f"Harness: {prov['harness']}. Model: {prov['model']} (local, Ollama). MCP servers: {', '.join(prov['mcp_servers']) or 'none'}. "
                f"Skills: {', '.join(prov['skills'])}. Subagents: {', '.join(prov['subagents'])}."),
              P("Tool calls: " + (", ".join(f"{k} x{v}" for k, v in prov["tool_calls"].items()) or "none")),
              P("Validation checks structure and traceability only. It does not prove the claims are true or clinically safe.", "small")]

    SimpleDocTemplate(str(path), pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=18 * mm,
                      title=r["title"], author="Mindful Policy Deep Agent").build(story, onFirstPage=_footer, onLaterPages=_footer)
