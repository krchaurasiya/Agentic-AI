"""JSON and Markdown exports of a finished run. The PDF lives in pdf.py. All three carry the same content."""
from __future__ import annotations

import json
from typing import Any

SCHEMA_VERSION = "1.0"


def _oneline(text: str, n: int) -> str:
    t = " ".join((text or "").split())
    return t if len(t) <= n else t[: n - 1].rstrip() + "…"


def _cell(text: str) -> str:
    return (text or "").replace("|", "\\|").replace("\n", " ")


def build_export_dict(result: dict[str, Any]) -> dict[str, Any]:
    """The JSON deliverable: report + evidence sources + validation + provenance."""
    return {
        "schema_version": SCHEMA_VERSION,
        "meta": {
            "run_id": result["run_id"], "created_at": result["created_at"], "question": result["request"]["question"],
            "geography": result["request"].get("geography"), "population": result["request"].get("population"),
            "format": "option / justification / trade-off",
        },
        "report": result["report"],
        "evidence_sources": result["evidence"],
        "validation": result["validation"],
        "provenance": result["provenance"],
        "disclaimer": "Policy research aid, not clinical, legal or safeguarding advice. Validation checks structure and traceability only; "
                      "verify every source before relying on it.",
    }


def to_json(result: dict[str, Any]) -> str:
    return json.dumps(build_export_dict(result), indent=2, ensure_ascii=False)


def to_markdown(result: dict[str, Any]) -> str:
    r, ev, val, prov = result["report"], result["evidence"], result["validation"], result["provenance"]
    ev_by_id = {e["id"]: e for e in ev}
    opts = r["options"]
    name_of = {o["id"]: o["option"] for o in opts}
    L: list[str] = [f"# {r['title']}", "",
                    f"**Policy question:** {result['request']['question']}  ",
                    f"**Run:** {result['run_id']} · {result['created_at'][:16].replace('T', ' ')} UTC · model `{prov['model']}` · "
                    f"structural validation {val['score']}/100 ({'passed' if val['passed'] else 'review needed'})", ""]
    notes = val.get("warnings", []) + ([f"Unresolved checks: {'; '.join(val['issues'])}"] if val.get("issues") else [])
    if notes:
        L += ["> **Read before relying on this report**", *[f"> - {n}" for n in notes], ""]
    L += ["## Executive summary", "", r["executive_summary"], "", "## Recommendation", ""]
    rec = r["recommendation"]
    L += [f"**Preferred first option: {rec['preferred_option_id']} — {name_of.get(rec['preferred_option_id'], '?')}.** {rec['rationale']}", ""]
    if rec.get("conditions"):
        L += ["This changes if:", *[f"- {c}" for c in rec["conditions"]], ""]
    L += ["## Options at a glance", "", "| Option | Justification | Main trade-off | Evidence |", "|---|---|---|---|"]
    for o in opts:
        L.append(f"| **{o['id']}** {_cell(o['option'])} | {_cell(_oneline(o['justification'], 170))} | "
                 f"{_cell(_oneline(o['trade_offs'][0] if o['trade_offs'] else '—', 120))} | {o['evidence_strength']} |")
    L += ["", "## Option details", ""]
    for o in opts:
        L += [f"### {o['id']} — {o['option']}", "", o["description"], "",
              f"**Justification** (evidence strength: *{o['evidence_strength']}*)", "", o["justification"], ""]
        if o["evidence_ids"]:
            L.append("Evidence: " + "; ".join(
                f"[{i}] {_oneline(ev_by_id[i]['title'], 70)}" for i in o["evidence_ids"] if i in ev_by_id))
            L.append("")
        L += ["**Trade-offs**", "", *[f"- {t}" for t in o["trade_offs"]], ""]
        if o.get("indicative_cost"):
            L += [f"**Indicative cost:** {o['indicative_cost']}", ""]
        if o.get("safeguards"):
            L += ["**Safeguards**", "", *[f"- {s}" for s in o["safeguards"]], ""]
    for head, key in [("Assumptions", "assumptions"), ("Evidence gaps", "evidence_gaps"),
                      ("Evaluation plan", "evaluation_plan"), ("Limitations", "limitations")]:
        if r.get(key):
            L += [f"## {head}", "", *[f"- {x}" for x in r[key]], ""]
    L += ["## Evidence sources", "",
          "Every source below was returned by a tool during this run. Status shows how far it was checked.", "",
          "| ID | Source | Year | Study type | Status | Cited by | Link |", "|---|---|---|---|---|---|---|"]
    for e in ev:
        link = f"[open]({e['url']})" if e.get("url") else "—"
        L.append(f"| {e['id']} | {_cell(_oneline(e['title'], 90))} — {_cell(e.get('source', ''))} | {(e.get('published') or '')[:4]} | "
                 f"{_cell(e.get('study_type', ''))} | {e['status']} | {', '.join(e.get('cited_by', [])) or 'not cited'} | {link} |")
    L += ["", "## Method and provenance", "",
          f"- Agent harness: {prov['harness']}",
          f"- Model: {prov['model']} (local, via Ollama)",
          f"- MCP servers: {', '.join(prov['mcp_servers']) or 'none (in-process fallback tools)'}",
          f"- Skills: {', '.join(prov['skills'])}",
          f"- Subagents: {', '.join(prov['subagents'])}",
          f"- Tool calls: {', '.join(f'{k} x{v}' for k, v in prov['tool_calls'].items()) or 'none'}",
          f"- Synthesis attempts: {len(result['attempts'])}", "",
          "*Policy research aid. Not clinical, legal or safeguarding advice. Validation checks structure and traceability, not truth.*", ""]
    return "\n".join(L)
