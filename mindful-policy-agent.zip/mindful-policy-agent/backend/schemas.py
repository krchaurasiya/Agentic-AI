"""Pydantic models: API request, the decision report the LLM must produce, and evidence records."""
from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field

DEFAULT_QUESTION = (
    "How can contemplative practices such as meditation be offered at scale "
    "to improve public mental wellbeing?"
)


class RunRequest(BaseModel):
    question: str = Field(default=DEFAULT_QUESTION, min_length=10, max_length=2000)
    context: str = Field(
        default="", max_length=20000,
        description="Optional background text (e.g. an essay). Treated as philosophical/context, never as evidence.",
    )
    geography: str = Field(default="India", max_length=200)
    population: str = Field(default="General public: schools, workplaces and communities", max_length=300)
    budget_context: str = Field(default="Use transparent illustrative assumptions unless local costs are given", max_length=300)
    max_retries: int | None = Field(default=None, ge=0, le=4)


# ---------------------------------------------------------------- decision report
class PolicyOption(BaseModel):
    """One option, in the requested format: option / justification / trade-off."""

    id: str = Field(description="Short id such as O1, O2, O3")
    option: str = Field(description="Name of the policy option (max 12 words)")
    description: str = Field(description="What it is, who delivers it and for whom (2-3 sentences)")
    justification: str = Field(
        description="Why this option is worth considering, grounded in evidence. Cite evidence ids like [E3]."
    )
    evidence_ids: list[str] = Field(description="Evidence ids (E#) that support the justification. Empty only if none exist.")
    evidence_strength: Literal["strong", "moderate", "limited", "none"] = Field(
        description="How strong the retrieved evidence is for this option"
    )
    trade_offs: list[str] = Field(description="At least two concrete costs, risks or things given up by choosing this option")
    indicative_cost: str = Field(default="", description="Cost note. Use calculation ids like [C1] if a calculator was used; otherwise say 'not estimated'.")
    safeguards: list[str] = Field(default_factory=list, description="Safeguards specific to this option")


class Recommendation(BaseModel):
    preferred_option_id: str = Field(description="Id of the option recommended first, e.g. O2")
    rationale: str = Field(description="Why, in 2-4 sentences, citing evidence ids")
    conditions: list[str] = Field(default_factory=list, description="Conditions under which the recommendation changes")


class DecisionReport(BaseModel):
    title: str
    executive_summary: str = Field(description="4-6 sentences. State what is known, what is uncertain, what to do first.")
    options: list[PolicyOption] = Field(description="3 to 5 distinct, voluntary policy options")
    recommendation: Recommendation
    assumptions: list[str] = Field(default_factory=list)
    evidence_gaps: list[str] = Field(default_factory=list)
    evaluation_plan: list[str] = Field(description="Concrete metrics, comparison design, follow-up")
    limitations: list[str]


# ---------------------------------------------------------------- evidence
class EvidenceItem(BaseModel):
    id: str                                   # E1.. for sources, C1.. for calculations
    kind: Literal["source", "calculation", "user_context"] = "source"
    title: str
    url: str = ""
    doi: str = ""
    source: str = ""                          # e.g. Europe PMC
    published: str = ""
    summary: str = ""
    limitations: str = ""
    study_type: str = "unclassified"
    study_type_basis: str = ""                # how study_type was decided
    status: Literal["retrieved", "fetched", "seed-unverified", "calculation", "user-supplied"] = "retrieved"
    via: str = ""                             # tool that returned it
    query: str = ""
    retrieved_at: str = ""
    cited_by: list[str] = Field(default_factory=list)   # option ids filled after synthesis
