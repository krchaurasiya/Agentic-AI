"""Headless run: python -m backend.cli --question "..."   -> writes outputs/<run>/decision.{json,md,pdf}"""
from __future__ import annotations

import argparse
import asyncio

from backend.config import settings
from backend.pipeline import PipelineError, new_run_id, run_pipeline
from backend.schemas import RunRequest


def main() -> None:
    p = argparse.ArgumentParser(description="Run the Mindful Policy Deep Agent from the command line.")
    p.add_argument("--question", default=RunRequest().question)
    p.add_argument("--context", default="")
    p.add_argument("--geography", default="India")
    p.add_argument("--max-retries", type=int, default=None)
    a = p.parse_args()

    def emit(kind: str, message: str = "", **_: object) -> None:
        if kind in ("stage", "info", "warn", "error", "validation", "synthesis", "plan", "delegate") or (kind == "tool_end"):
            print(f"[{kind}] {message}")

    req = RunRequest(question=a.question, context=a.context, geography=a.geography, max_retries=a.max_retries)
    try:
        res = asyncio.run(run_pipeline(new_run_id(), req, emit))
    except PipelineError as exc:
        raise SystemExit(f"\nError: {exc}")
    folder = settings.path(settings.outputs_dir) / res["run_id"]
    print(f"\nValidation {res['validation']['score']}/100. Files written to {folder}:")
    for f in res["files"].values():
        print("  ", folder / f)


if __name__ == "__main__":
    main()
