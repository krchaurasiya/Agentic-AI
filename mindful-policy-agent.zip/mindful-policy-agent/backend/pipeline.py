"""End-to-end run: setup -> research (Deep Agent) -> synthesis (option/justification/trade-off) -> validate -> export."""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from collections import Counter
from datetime import datetime, timezone
from importlib import metadata
from typing import Any, Callable

import httpx
from langchain_core.language_models import BaseChatModel

from backend.agent.harness import SKILLS_DIR, build_agent, build_model
from backend.config import settings
from backend.evidence import EvidenceRegistry
from backend.export.pdf import build_pdf
from backend.export.render import to_json, to_markdown
from backend.mcp_client import mcp_tools
from backend.schemas import DecisionReport, RunRequest
from backend.synthesis import synthesize
from backend.tools.instrument import instrument
from backend.tools.native import FALLBACK_RESEARCH_TOOLS, make_local_tools

Emit = Callable[..., None]


class PipelineError(Exception):
    """A problem the user can act on (shown verbatim in the UI)."""


def new_run_id() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]


async def check_ollama() -> None:
    try:
        async with httpx.AsyncClient(timeout=4) as c:
            names = [m.get("name", "") for m in (await c.get(f"{settings.ollama_base_url}/api/tags")).json().get("models", [])]
    except Exception as exc:  # noqa: BLE001
        raise PipelineError(f"Cannot reach Ollama at {settings.ollama_base_url} ({type(exc).__name__}). Install Ollama from https://ollama.com and start it.") from exc
    if not any(n == settings.ollama_model or n.startswith(settings.ollama_model + ":") or n.split(":")[0] == settings.ollama_model for n in names):
        raise PipelineError(f"Model '{settings.ollama_model}' is not installed. Run:  ollama pull {settings.ollama_model}")


def _research_prompt(req: RunRequest) -> str:
    ctx = req.context.strip()[:2500]
    return (
        f"POLICY QUESTION: {req.question}\nGEOGRAPHY: {req.geography}\nTARGET POPULATION: {req.population}\n"
        f"BUDGET CONTEXT: {req.budget_context}\n"
        + (f"BACKGROUND TEXT FROM USER (context only, not evidence):\n{ctx}\n" if ctx else "")
        + "\nPlan with write_todos, research with the subagents and tools, then finish with the RESEARCH BRIEF."
    )


def _text_of(msg: Any) -> str:
    c = getattr(msg, "content", "")
    return c if isinstance(c, str) else "".join(b.get("text", "") if isinstance(b, dict) else str(b) for b in c)


async def _run_research(agent: Any, req: RunRequest, emit: Emit) -> str:
    """Stream the Deep Agent; surface its plan and delegations as events; return the final brief."""
    brief = ""
    async for chunk in agent.astream({"messages": [{"role": "user", "content": _research_prompt(req)}]},
                                     config={"recursion_limit": settings.agent_recursion_limit}, stream_mode="updates"):
        for node, update in chunk.items():
            msgs = update.get("messages") if isinstance(update, dict) else None
            if not isinstance(msgs, list):
                continue
            for m in msgs:
                if getattr(m, "type", "") != "ai":
                    continue
                calls = getattr(m, "tool_calls", None) or []
                for c in calls:
                    if c["name"] == "write_todos":
                        todos = c["args"].get("todos", [])
                        emit("plan", message=f"Plan updated ({len(todos)} steps)", todos=todos)
                    elif c["name"] == "task":
                        emit("delegate", message=f"Delegated to {c['args'].get('subagent_type', 'subagent')}",
                             subagent=c["args"].get("subagent_type"), task=str(c["args"].get("description", ""))[:240])
                    elif c["name"] in ("read_file", "write_file", "edit_file", "ls", "glob", "grep"):
                        emit("harness", message=f"{c['name']} {c['args'].get('file_path', c['args'].get('path', ''))}".strip())
                if not calls and _text_of(m).strip():
                    brief = _text_of(m)
    return brief


def _versions() -> str:
    out = []
    for p in ("deepagents", "langchain", "langgraph", "langchain-ollama", "langchain-mcp-adapters", "mcp"):
        try:
            out.append(f"{p} {metadata.version(p)}")
        except metadata.PackageNotFoundError:
            pass
    return ", ".join(out)


async def run_pipeline(run_id: str, req: RunRequest, emit: Emit, *, agent_model: BaseChatModel | None = None,
                       synthesis_model: BaseChatModel | None = None, use_mcp_override: bool | None = None) -> dict[str, Any]:
    t_start = time.time()
    created = datetime.now(timezone.utc).isoformat(timespec="seconds")
    max_retries = settings.max_review_retries if req.max_retries is None else req.max_retries

    emit("stage", message="Checking local model", stage="setup", status="start")
    if agent_model is None:
        await check_ollama()
    registry = EvidenceRegistry()
    registry.add_user_context(req.context)
    agent_model = agent_model or build_model()
    synthesis_model = synthesis_model or build_model(json_schema=DecisionReport.model_json_schema())

    tool_counter: Counter[str] = Counter()

    def counting_emit(kind: str, **kw: Any) -> None:
        if kind == "tool_start":
            tool_counter[kw.get("tool", "?")] += 1
        emit(kind, **kw)

    brief = ""
    mcp_names: list[str] = []
    async with mcp_tools(counting_emit) as (mcp, mcp_names):
        if use_mcp_override is False:
            mcp, mcp_names = [], []
        base = mcp if mcp else FALLBACK_RESEARCH_TOOLS
        if not mcp:
            emit("info", message="Using in-process research tools (MCP not connected).")
        tools = [instrument(t, registry, counting_emit) for t in [*base, *make_local_tools(registry)]]
        emit("stage", message="Checking local model", stage="setup", status="done")

        emit("stage", message="Researching evidence", stage="research", status="start")
        agent = build_agent(agent_model, tools)
        try:
            async with asyncio.timeout(settings.run_timeout_seconds):
                brief = await _run_research(agent, req, counting_emit)
        except TimeoutError:
            emit("warn", message="Research hit the time limit; continuing with what was gathered.")
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            emit("warn", message=f"Research agent stopped early ({type(exc).__name__}: {str(exc)[:160]}); continuing with what was gathered.")
        if not brief.strip():
            brief = "(The research agent did not produce a brief. Use only the evidence list.)"
        n_src = sum(1 for i in registry.all() if i.kind == "source")
        emit("stage", message=f"Research done: {n_src} source(s) gathered", stage="research", status="done", sources=n_src)

    emit("stage", message="Writing decision options", stage="synthesis", status="start")
    report, validation, attempts, _notes = await synthesize(synthesis_model, req, brief, registry, emit, max_retries)
    if report is None:
        raise PipelineError("The model could not produce a valid decision report. Try again, raise 'review retries', or use a larger model "
                            "(set OLLAMA_MODEL in .env).")
    emit("stage", message="Writing decision options", stage="synthesis", status="done")

    emit("stage", message="Exporting JSON, Markdown and PDF", stage="export", status="start")
    skills = sorted(p.parent.name for p in SKILLS_DIR.glob("*/SKILL.md"))
    result: dict[str, Any] = {
        "run_id": run_id, "created_at": created, "request": req.model_dump(), "report": report.model_dump(),
        "evidence": [e.model_dump() for e in registry.all()], "validation": validation, "attempts": attempts,
        "research_brief": brief,
        "provenance": {
            "model": settings.ollama_model, "harness": "LangChain Deep Agents (planning, virtual filesystem, subagents, skills)",
            "mcp_servers": mcp_names, "skills": skills, "subagents": ["evidence-researcher", "options-analyst"],
            "tool_calls": dict(tool_counter), "versions": _versions(), "duration_seconds": round(time.time() - t_start, 1),
        },
    }
    out = settings.path(settings.outputs_dir) / run_id
    out.mkdir(parents=True, exist_ok=True)
    (out / "decision.json").write_text(to_json(result), encoding="utf-8")
    (out / "decision.md").write_text(to_markdown(result), encoding="utf-8")
    build_pdf(result, out / "decision.pdf")
    result["files"] = {"json": "decision.json", "md": "decision.md", "pdf": "decision.pdf"}
    emit("stage", message="Exporting JSON, Markdown and PDF", stage="export", status="done")
    return result
