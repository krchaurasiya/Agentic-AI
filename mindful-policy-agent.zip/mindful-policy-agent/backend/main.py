"""FastAPI app: JSON API under /api, and the pre-built React UI at /."""
from __future__ import annotations

import re
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend import storage
from backend.catalog import stack
from backend.config import ROOT, settings
from backend.runs import manager
from backend.schemas import DecisionReport, EvidenceItem, RunRequest

RUN_ID = re.compile(r"^\d{8}-\d{6}-[0-9a-f]{4}$")
FILES = {"json": ("decision.json", "application/json"), "md": ("decision.md", "text/markdown; charset=utf-8"),
         "pdf": ("decision.pdf", "application/pdf")}
DIST = ROOT / "frontend" / "dist"


@asynccontextmanager
async def lifespan(_: FastAPI):
    storage.mark_interrupted()
    yield


app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_methods=["GET", "POST", "DELETE"], allow_headers=["*"])


def _check_id(run_id: str) -> str:
    if not RUN_ID.match(run_id):
        raise HTTPException(404, "Run not found")
    return run_id


@app.get("/api/health")
async def health() -> dict:
    ollama = {"reachable": False, "model_installed": False}
    try:
        async with httpx.AsyncClient(timeout=2.5) as c:
            names = [m.get("name", "") for m in (await c.get(f"{settings.ollama_base_url}/api/tags")).json().get("models", [])]
        ollama = {"reachable": True, "model_installed": any(n == settings.ollama_model or n.split(":")[0] == settings.ollama_model.split(":")[0] and n.startswith(settings.ollama_model) for n in names)}
    except Exception:  # noqa: BLE001
        pass
    return {"status": "ok", "app": settings.app_name, "model": settings.ollama_model, "ollama": ollama,
            "mcp_enabled": settings.use_mcp, "default_question": RunRequest().question}


@app.get("/api/stack")
def get_stack() -> dict:
    return stack()


@app.get("/api/schema")
def get_schema() -> dict:
    return {"decision_report": DecisionReport.model_json_schema(), "evidence_item": EvidenceItem.model_json_schema()}


@app.post("/api/runs", status_code=202)
async def create_run(req: RunRequest) -> dict:
    s = manager.start(req)
    return {"id": s.id, "status": s.status}


@app.get("/api/runs")
def list_runs(limit: int = 30) -> dict:
    return {"runs": storage.list_runs(limit)}


@app.get("/api/runs/{run_id}")
def get_run(run_id: str, after: int = Query(0, ge=0)) -> dict:
    _check_id(run_id)
    s = manager.runs.get(run_id)
    if s:
        return {"id": s.id, "status": s.status, "error": s.error, "request": s.request.model_dump(), "created_at": s.created_at,
                "events": s.events[after:], "next": len(s.events), "result": s.result if s.status == "done" else None}
    saved = storage.get_run(run_id)
    if not saved:
        raise HTTPException(404, "Run not found")
    return {**saved, "events": saved["events"][after:], "next": len(saved["events"])}


@app.post("/api/runs/{run_id}/cancel")
def cancel(run_id: str) -> dict:
    _check_id(run_id)
    return {"cancelled": manager.cancel(run_id)}


@app.delete("/api/runs/{run_id}")
def delete(run_id: str) -> dict:
    _check_id(run_id)
    s = manager.runs.get(run_id)
    if s and s.status in ("queued", "running"):
        raise HTTPException(409, "Cancel the run before deleting it")
    manager.runs.pop(run_id, None)
    storage.delete_run(run_id)
    import shutil
    shutil.rmtree(settings.path(settings.outputs_dir) / run_id, ignore_errors=True)
    return {"deleted": True}


@app.get("/api/runs/{run_id}/files/{fmt}")
def download(run_id: str, fmt: str, inline: bool = False):
    _check_id(run_id)
    if fmt not in FILES:
        raise HTTPException(404, "Unknown format")
    name, media = FILES[fmt]
    path = settings.path(settings.outputs_dir) / run_id / name
    if not path.is_file():
        raise HTTPException(404, "File not available for this run")
    disposition = "inline" if inline else "attachment"
    return FileResponse(path, media_type=media, headers={"Content-Disposition": f'{disposition}; filename="policy-decision-{run_id}.{fmt}"'})


# ---- React UI (pre-built). If frontend/dist is missing, say how to build it.
if (DIST / "index.html").is_file():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        if path == "api" or path.startswith("api/"):
            raise HTTPException(404, "Not found")
        target = (DIST / path).resolve()
        if path and target.is_file() and DIST in target.parents:
            return FileResponse(target)
        return FileResponse(DIST / "index.html")
else:
    @app.get("/", include_in_schema=False)
    def no_ui() -> dict:
        return {"message": "UI not built. Run: cd frontend && npm install && npm run build  (or use the API docs at /docs)."}
