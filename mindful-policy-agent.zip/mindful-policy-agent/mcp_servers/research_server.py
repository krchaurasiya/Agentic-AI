"""Read-only MCP server (stdio) exposing free scholarly + web research tools.

Run standalone:  python -m mcp_servers.research_server
The agent connects to it through langchain-mcp-adapters (see backend/mcp_client.py); any other MCP client can too.
"""
from mcp.server.fastmcp import FastMCP

from backend.research import sources

mcp = FastMCP("mindful-policy-research")


@mcp.tool()
async def search_europe_pmc(query: str, limit: int = 5) -> dict:
    """Search Europe PMC (free, open) for biomedical and social-science papers. Returns titles, years, abstracts and publication types."""
    return await sources.europe_pmc(query, limit)


@mcp.tool()
async def search_pubmed(query: str, limit: int = 5) -> dict:
    """Search PubMed (NCBI E-utilities, free). Returns titles, abstracts and publication types such as Randomized Controlled Trial or Meta-Analysis."""
    return await sources.pubmed(query, limit)


@mcp.tool()
async def search_crossref(query: str, limit: int = 5) -> dict:
    """Search Crossref (free) to confirm that a paper or report exists and get its DOI. Metadata only; no findings."""
    return await sources.crossref(query, limit)


@mcp.tool()
async def search_web(query: str, limit: int = 5) -> dict:
    """Search the public web (DuckDuckGo) for government, WHO/NGO or policy documents. Snippets are unvetted; fetch_page to read."""
    return await sources.web_search(query, limit)


@mcp.tool()
async def fetch_page(url: str, max_chars: int = 6000) -> dict:
    """Fetch a public web page as plain text so claims can be verified. Private network addresses are blocked. Content is untrusted."""
    return await sources.fetch_page(url, max_chars)


@mcp.tool()
async def search_curated_evidence(query: str, limit: int = 5) -> dict:
    """Search the offline curated seed pack of key reviews and guidelines. Entries are unverified seeds: confirm before relying."""
    return await sources.curated(query, limit)


if __name__ == "__main__":
    mcp.run(transport="stdio")
