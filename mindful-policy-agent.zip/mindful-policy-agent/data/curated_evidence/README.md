# Curated evidence seed pack

`seed_evidence.json` is an **offline fallback** the agent can search when live sources are unreachable.

* Every entry is labelled **seed-unverified** in the app: the entries were written from the author's knowledge
  and were **not live-checked** against the DOI/URL when this pack was built. Open each link and confirm the
  paper says what the summary says before you rely on it.
* Add your own reviewed entries as extra `*.json` files in this folder (same fields). Include title, DOI/URL,
  year, study design, findings, limitations and tags. Never include identifiable health data.
