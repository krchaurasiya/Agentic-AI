import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "./api.js";
import Ask from "./Ask.jsx";
import RunView from "./RunView.jsx";
import Decision from "./Decision.jsx";
import Stack from "./Stack.jsx";

const ACTIVE = ["queued", "running"];

export default function App() {
  const [view, setView] = useState("ask");          // ask | run | stack
  const [health, setHealth] = useState(null);
  const [history, setHistory] = useState([]);
  const [run, setRun] = useState(null);             // { id, status, events, result, error, request }
  const [startError, setStartError] = useState("");
  const timer = useRef(null);
  const cursor = useRef(0);

  const refreshHistory = useCallback(() => api.runs().then((d) => setHistory(d.runs)).catch(() => {}), []);
  useEffect(() => { api.health().then(setHealth).catch(() => setHealth({ status: "down" })); refreshHistory(); }, [refreshHistory]);

  const stop = () => { clearTimeout(timer.current); timer.current = null; };
  const poll = useCallback(async (id) => {
    try {
      const d = await api.run(id, cursor.current);
      cursor.current = d.next;
      setRun((prev) => ({ ...(prev?.id === id ? prev : {}), ...d, events: [...(prev?.id === id ? prev.events : []), ...d.events] }));
      if (ACTIVE.includes(d.status)) timer.current = setTimeout(() => poll(id), 1200);
      else refreshHistory();
    } catch (e) {
      timer.current = setTimeout(() => poll(id), 3000);
    }
  }, [refreshHistory]);
  useEffect(() => stop, []);

  const open = (id) => { stop(); cursor.current = 0; setRun({ id, status: "queued", events: [] }); setView("run"); poll(id); };
  const start = async (body) => {
    setStartError("");
    try { const { id } = await api.start(body); refreshHistory(); open(id); }
    catch (e) { setStartError(e.message); }
  };
  const cancel = () => run && api.cancel(run.id).then(() => poll(run.id));
  const remove = async (id) => {
    await api.remove(id).catch((e) => alert(e.message));
    if (run?.id === id) { stop(); setRun(null); setView("ask"); }
    refreshHistory();
  };

  const done = run?.status === "done" && run.result;
  return (
    <div className="shell">
      <aside className="rail" aria-label="Navigation">
        <div className="brand"><span className="mark" aria-hidden="true" /><div><strong>Mindful Policy</strong><span>Deep Agent</span></div></div>
        <nav>
          <button className={view === "ask" ? "on" : ""} onClick={() => setView("ask")}>New analysis</button>
          <button className={view === "stack" ? "on" : ""} onClick={() => setView("stack")}>What it is built from</button>
        </nav>
        <h2 className="rail-h">Past analyses</h2>
        <ul className="history">
          {history.length === 0 && <li className="muted small">Nothing yet. Ask a question to begin.</li>}
          {history.map((h) => (
            <li key={h.id}>
              <button className={run?.id === h.id && view === "run" ? "on" : ""} onClick={() => open(h.id)}>
                <span className={`dot ${h.status}`} aria-label={h.status} />
                <span className="q">{h.question}</span>
                <span className="small muted">{h.created_at.slice(0, 10)}{h.score != null ? ` · ${h.score}/100` : ""}</span>
              </button>
              {!ACTIVE.includes(h.status) && <button className="x" title="Delete this analysis" aria-label="Delete this analysis" onClick={() => remove(h.id)}>×</button>}
            </li>
          ))}
        </ul>
        <Health h={health} />
      </aside>

      <main>
        {view === "ask" && <Ask health={health} onStart={start} error={startError} />}
        {view === "stack" && <Stack />}
        {view === "run" && run && (done ? <Decision run={run} /> : <RunView run={run} onCancel={cancel} onBack={() => setView("ask")} />)}
      </main>
    </div>
  );
}

function Health({ h }) {
  if (!h) return null;
  const o = h.ollama;
  let text = "Checking local model…", cls = "";
  if (h.status === "down") { text = "Backend not reachable"; cls = "bad"; }
  else if (!o?.reachable) { text = "Ollama not running. Start it, then reload."; cls = "bad"; }
  else if (!o.model_installed) { text = `Model missing. Run: ollama pull ${h.model}`; cls = "bad"; }
  else { text = `${h.model} ready, running locally`; cls = "good"; }
  return <div className={`health ${cls}`} role="status"><span className="dot" />{text}</div>;
}
