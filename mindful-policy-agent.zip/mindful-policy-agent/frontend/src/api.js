const j = async (r) => {
  if (!r.ok) {
    let msg = `${r.status} ${r.statusText}`;
    try { const b = await r.json(); msg = typeof b.detail === "string" ? b.detail : JSON.stringify(b.detail ?? b); } catch {}
    throw new Error(msg);
  }
  return r.json();
};

export const api = {
  health: () => fetch("/api/health").then(j),
  stack: () => fetch("/api/stack").then(j),
  runs: () => fetch("/api/runs").then(j),
  run: (id, after = 0) => fetch(`/api/runs/${id}?after=${after}`).then(j),
  start: (body) => fetch("/api/runs", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(j),
  cancel: (id) => fetch(`/api/runs/${id}/cancel`, { method: "POST" }).then(j),
  remove: (id) => fetch(`/api/runs/${id}`, { method: "DELETE" }).then(j),
  fileUrl: (id, fmt, inline = false) => `/api/runs/${id}/files/${fmt}${inline ? "?inline=true" : ""}`,
};
