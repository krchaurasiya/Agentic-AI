const STAGES = [
  ["setup", "Check model and tools"], ["research", "Research evidence"],
  ["synthesis", "Write decision options"], ["export", "Export JSON, Markdown, PDF"],
];

const label = (e) => {
  const d = e.data || {};
  switch (e.type) {
    case "tool_end": return `${d.tool}${d.args?.query ? ` “${d.args.query}”` : d.args?.url ? ` ${d.args.url}` : ""}: ${d.ok === false ? "failed" : d.n_results != null && d.n_results > 0 ? `${d.n_results} source(s)` : "done"}${d.seconds != null ? ` (${d.seconds}s)` : ""}`;
    case "tool_start": return `Running ${d.tool}${d.args?.query ? ` “${d.args.query}”` : ""}…`;
    default: return e.message;
  }
};

export default function RunView({ run, onCancel, onBack }) {
  const ev = run.events || [];
  const stage = {};
  ev.filter((e) => e.type === "stage").forEach((e) => { stage[e.data.stage] = e.data.status; });
  const todos = [...ev].reverse().find((e) => e.type === "plan")?.data?.todos || [];
  const sources = [...ev].reverse().find((e) => e.data?.sources != null)?.data?.sources;
  const toolsDone = ev.filter((e) => e.type === "tool_end");
  const last = ev[ev.length - 1];
  const feed = ev.filter((e) => (e.type !== "tool_start" || e === last) && !(e.type === "stage" && e.data?.status === "done" && e.data?.stage !== "research")).slice(-60);
  const active = ["queued", "running"].includes(run.status);

  return (
    <section className="page">
      <header className="run-head">
        <div>
          <h1>{active ? (run.status === "queued" ? "Waiting in the queue" : "The agent is working") : run.status === "failed" ? "This run stopped" : run.status === "cancelled" ? "Run cancelled" : run.status === "interrupted" ? "Run interrupted" : "Run"}</h1>
          <p className="lede q">{run.request?.question}</p>
        </div>
        {active ? <button className="ghost" onClick={onCancel}>Cancel run</button> : <button className="ghost" onClick={onBack}>New analysis</button>}
      </header>

      {run.error && <p className="alert" role="alert">{run.error}</p>}

      <ol className="steps" aria-label="Progress">
        {STAGES.map(([k, name]) => (
          <li key={k} className={stage[k] === "done" ? "done" : stage[k] === "start" ? "now" : ""}>
            <span className="bullet" aria-hidden="true" />{name}
            {k === "research" && sources != null && <span className="muted small"> · {sources} sources</span>}
          </li>
        ))}
      </ol>

      <div className="cols">
        <div>
          <h2>Agent activity</h2>
          <ul className="feed" aria-live="polite">
            {feed.length === 0 && <li className="muted">Starting…</li>}
            {feed.map((e) => (
              <li key={e.i} className={`ev ${e.type} ${e.type === "tool_end" && e.data?.ok === false ? "fail" : ""}`}>
                <span className="kind">{{ tool_start: "tool", tool_end: "tool", delegate: "subagent", harness: "harness", plan: "plan", synthesis: "write", validation: "check", warn: "note", error: "error", stage: "stage", info: "info", done: "done" }[e.type] || e.type}</span>
                <span>{label(e)}{e.type === "delegate" && e.data?.task ? <em className="muted small"> {e.data.task}</em> : ""}</span>
              </li>
            ))}
          </ul>
        </div>
        <aside>
          <h2>Agent’s plan</h2>
          {todos.length === 0 ? <p className="muted small">The agent writes its plan first. It appears here.</p> : (
            <ul className="todos">{todos.map((t, i) => <li key={i} className={t.status}><span aria-hidden="true" className="tick">{t.status === "completed" ? "✓" : t.status === "in_progress" ? "…" : "·"}</span>{t.content}</li>)}</ul>
          )}
          <p className="muted small">{toolsDone.length} tool call(s) so far.</p>
        </aside>
      </div>
    </section>
  );
}
