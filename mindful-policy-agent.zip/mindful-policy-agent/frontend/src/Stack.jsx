import { useEffect, useState } from "react";
import { api } from "./api.js";

export default function Stack() {
  const [s, setS] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => { api.stack().then(setS).catch((e) => setErr(e.message)); }, []);
  if (err) return <section className="page"><p className="alert">{err}</p></section>;
  if (!s) return <section className="page"><p className="muted">Loading…</p></section>;
  return (
    <section className="page">
      <h1>What it is built from</h1>
      <p className="lede">Everything is free to use and open source. The language model runs on your computer. Only search keywords leave it, when the research tools run.</p>

      <h2>Evidence sources</h2>
      <div className="table-wrap"><table>
        <thead><tr><th>Source</th><th>What it gives the agent</th><th>Key needed</th><th>Limits</th></tr></thead>
        <tbody>{s.evidence_sources.map((e) => (
          <tr key={e.name}><td><b>{e.url ? <a href={e.url} target="_blank" rel="noreferrer noopener">{e.name}</a> : e.name}</b><div className="small muted">{e.kind}{e.tool ? ` · ${e.tool}` : ""}</div></td><td>{e.gives}</td><td>{e.key}</td><td>{e.limits}</td></tr>
        ))}</tbody>
      </table></div>

      <h2>Agent harness and subagents</h2>
      <ul className="plain">
        {s.subagents.map((a) => <li key={a.name}><b>{a.name}</b>: {a.does}</li>)}
        <li><b>Research lead</b>: plans with todos, delegates, reads skills, writes the research brief. A second stage turns the brief into options, and a checker validates it.</li>
      </ul>

      <h2>Tools</h2>
      <div className="table-wrap"><table><thead><tr><th>Tool</th><th>Where it runs</th><th>What it does</th></tr></thead>
        <tbody>{s.tools.map((t) => <tr key={t.name}><td><code>{t.name}</code></td><td>{t.where}</td><td>{t.does}</td></tr>)}</tbody></table></div>

      <h2>MCP servers</h2>
      <ul className="plain">{s.mcp_servers.map((m) => <li key={m.name}><b>{m.name}</b> <span className={`badge ${m.enabled ? "retrieved" : "seed-unverified"}`}>{m.enabled ? "enabled" : "off"}</span> {m.description}</li>)}</ul>

      <h2>Skills</h2>
      <ul className="plain">{s.skills.map((k) => <li key={k.name}><b>{k.name}</b>: {k.description}</li>)}</ul>

      <h2>Software</h2>
      {Object.entries(s.components).map(([group, rows]) => (
        <div key={group}><h3>{group}</h3>
          <div className="table-wrap"><table><thead><tr><th>Name</th><th>Licence</th><th>Cost</th><th>Role</th></tr></thead>
            <tbody>{rows.map((r) => <tr key={r.name}><td>{r.name}{r.version ? <span className="muted small"> {r.version}</span> : ""}</td><td>{r.license}</td><td>{r.cost}</td><td>{r.role}</td></tr>)}</tbody></table></div>
        </div>
      ))}
    </section>
  );
}
