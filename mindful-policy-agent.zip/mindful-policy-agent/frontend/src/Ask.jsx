import { useEffect, useState } from "react";

const EXAMPLES = [
  "How can contemplative practices such as meditation be offered at scale to improve public mental wellbeing?",
  "Should workplaces in India offer optional mindfulness sessions to reduce employee stress?",
  "What is the best way to bring wellbeing practices into government schools without mandating them?",
];

export default function Ask({ health, onStart, error }) {
  const [f, setF] = useState({
    question: EXAMPLES[0], context: "", geography: "India",
    population: "General public: schools, workplaces and communities",
    budget_context: "Use transparent illustrative assumptions unless local costs are given", max_retries: 2,
  });
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (error) setBusy(false); }, [error]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const ready = health?.ollama?.reachable && health?.ollama?.model_installed;
  const submit = (e) => { e.preventDefault(); setBusy(true); onStart({ ...f, max_retries: Number(f.max_retries) }); };

  return (
    <section className="page narrow">
      <h1>What policy decision are you weighing?</h1>
      <p className="lede">The agent researches free scholarly sources, then returns each option with its <b className="j">justification</b> and its <b className="t">trade-offs</b>, plus the evidence it relied on.</p>
      <form onSubmit={submit} className="form">
        <label><span>Policy question</span>
          <textarea rows={3} value={f.question} onChange={set("question")} minLength={10} maxLength={2000} required />
        </label>
        <div className="chips" aria-label="Example questions">
          {EXAMPLES.slice(1).map((x) => <button type="button" key={x} className="chip" onClick={() => setF({ ...f, question: x })}>{x.length > 62 ? x.slice(0, 60) + "…" : x}</button>)}
        </div>
        <label><span>Background text <span className="muted">(optional; treated as context, never as evidence)</span></span>
          <textarea rows={4} value={f.context} onChange={set("context")} placeholder="Paste an essay or notes, for example the article behind your question." maxLength={20000} />
        </label>
        <div className="grid2">
          <label><span>Geography</span><input value={f.geography} onChange={set("geography")} /></label>
          <label><span>Who is it for</span><input value={f.population} onChange={set("population")} /></label>
        </div>
        <label><span>Cost assumptions</span><input value={f.budget_context} onChange={set("budget_context")} /></label>
        <label className="inline">Review retries
          <select value={f.max_retries} onChange={set("max_retries")}>{[0, 1, 2, 3, 4].map((n) => <option key={n}>{n}</option>)}</select>
          <span className="muted small">Extra drafting passes if the checks find problems.</span>
        </label>
        {error && <p className="alert" role="alert">{error}</p>}
        <div className="actions">
          <button className="primary" disabled={busy || !ready}>{busy ? "Starting…" : "Run analysis"}</button>
          {!ready && health && <span className="small bad-text">The local model is not ready yet (see the status at the bottom left).</span>}
          {ready && <span className="small muted">A local 8B model can take 10 to 30 minutes. You can leave this page and come back from Past analyses.</span>}
        </div>
      </form>
      <p className="small muted fine">Policy research aid only. Participation in any programme should be voluntary, and meditation does not replace qualified mental-health care.</p>
    </section>
  );
}
