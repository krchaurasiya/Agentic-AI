import { useState } from "react";
import { api } from "./api.js";

const STATUS = {
  retrieved: ["Abstract read", "Abstract or snippet only"],
  fetched: ["Page read", "The agent read the page text"],
  "seed-unverified": ["Seed, unverified", "From the offline pack. Open the link and confirm before relying on it"],
  calculation: ["Calculation", "Illustrative arithmetic from stated assumptions"],
  "user-supplied": ["Your text", "Context you supplied, not evidence"],
};

function Cited({ text, ev, onPick }) {
  // turn [E3] / [C1] markers into buttons
  return text.split(/(\[[ECU]\d{1,3}\])/g).map((p, i) => {
    const m = p.match(/^\[([ECU]\d{1,3})\]$/);
    if (!m) return p;
    return ev[m[1]] ? <button key={i} className="cite" onClick={() => onPick(m[1])} aria-label={`Show source ${m[1]}`}>{m[1]}</button> : p;
  });
}

function SourceCard({ e, onClose }) {
  const [label, hint] = STATUS[e.status] || [e.status, ""];
  return (
    <div className="source-card" role="region" aria-label={`Source ${e.id}`}>
      <div className="sc-top"><b>{e.id}</b><span className={`badge ${e.status}`} title={hint}>{label}</span><button className="x" onClick={onClose} aria-label="Close source">×</button></div>
      <p className="sc-title">{e.title}</p>
      <p className="small muted">{[e.source, (e.published || "").slice(0, 4), e.study_type].filter(Boolean).join(" · ")}{e.study_type_basis ? ` (${e.study_type_basis})` : ""}</p>
      {e.summary && <p className="small">{e.summary.slice(0, 520)}{e.summary.length > 520 ? "…" : ""}</p>}
      {e.limitations && <p className="small muted">Limits: {e.limitations}</p>}
      {e.url && <a href={e.url} target="_blank" rel="noreferrer noopener" className="small">Open source ↗</a>}
    </div>
  );
}

export default function Decision({ run }) {
  const { result: r, id } = run;
  const rep = r.report, val = r.validation, prov = r.provenance;
  const evList = r.evidence;
  const ev = Object.fromEntries(evList.map((e) => [e.id, e]));
  const [picked, setPicked] = useState(null);
  const nameOf = Object.fromEntries(rep.options.map((o) => [o.id, o.option]));
  const rec = rep.recommendation;
  const notes = [...(val.warnings || []), ...(val.issues?.length ? [`Unresolved checks: ${val.issues.join("; ")}`] : [])];
  const pick = (cid) => setPicked(cid);

  return (
    <article className="page decision">
      <header className="d-head">
        <div>
          <h1>{rep.title}</h1>
          <p className="lede q">{r.request.question}</p>
          <p className="small muted">{new Date(r.created_at).toLocaleString()} · {prov.model} (local) · {prov.duration_seconds < 90 ? `${Math.round(prov.duration_seconds)} s` : `${Math.round(prov.duration_seconds / 60)} min`}</p>
        </div>
        <div className="downloads" role="group" aria-label="Download">
          <a className="primary" href={api.fileUrl(id, "pdf")}>Download PDF</a>
          <a className="ghost" href={api.fileUrl(id, "md")}>Markdown</a>
          <a className="ghost" href={api.fileUrl(id, "json")}>JSON</a>
        </div>
      </header>

      <nav className="jump" aria-label="Sections">
        {[["summary", "Summary"], ["options", `Options (${rep.options.length})`], ["evidence", `Evidence (${evList.length})`], ["checks", "Checks and method"]].map(([a, t]) => <a key={a} href={`#${a}`}>{t}</a>)}
      </nav>

      {notes.length > 0 && <div className="callout" role="note"><b>Read before relying on this</b><ul>{notes.map((n, i) => <li key={i}>{n}</li>)}</ul></div>}

      <section id="summary">
        <h2>Summary</h2>
        <p className="prose">{rep.executive_summary}</p>
        <div className="rec">
          <span className="small muted">Recommended first</span>
          <h3>{rec.preferred_option_id}: {nameOf[rec.preferred_option_id] || "?"}</h3>
          <p className="prose"><Cited text={rec.rationale} ev={ev} onPick={pick} /></p>
          {rec.conditions?.length > 0 && <p className="small"><b>This changes if:</b> {rec.conditions.join("; ")}</p>}
        </div>
      </section>

      <section id="options">
        <h2>Options</h2>
        <p className="small muted legend"><span className="sw j" /> why it is worth considering <span className="sw t" /> what you give up</p>
        {rep.options.map((o) => (
          <div className="option" key={o.id}>
            <header>
              <h3><span className="oid">{o.id}</span>{o.option}</h3>
              <span className={`strength ${o.evidence_strength}`} title="How strong the retrieved evidence is for this option">Evidence: {o.evidence_strength}</span>
            </header>
            <p className="desc">{o.description}</p>
            <div className="balance">
              <div className="j">
                <h4>Justification</h4>
                <p className="prose"><Cited text={o.justification} ev={ev} onPick={pick} /></p>
              </div>
              <div className="t">
                <h4>Trade-offs</h4>
                <ul>{o.trade_offs.map((t, i) => <li key={i}>{t}</li>)}</ul>
              </div>
            </div>
            {(o.indicative_cost || o.safeguards?.length > 0) && (
              <dl className="facts">
                {o.indicative_cost && <><dt>Indicative cost</dt><dd><Cited text={o.indicative_cost} ev={ev} onPick={pick} /></dd></>}
                {o.safeguards?.length > 0 && <><dt>Safeguards</dt><dd>{o.safeguards.join("; ")}</dd></>}
              </dl>
            )}
            {picked && o.evidence_ids.includes(picked) && ev[picked] && <SourceCard e={ev[picked]} onClose={() => setPicked(null)} />}
          </div>
        ))}
        {picked && ev[picked] && !rep.options.some((o) => o.evidence_ids.includes(picked)) && <SourceCard e={ev[picked]} onClose={() => setPicked(null)} />}
        {[["Assumptions", rep.assumptions], ["Evidence gaps", rep.evidence_gaps], ["Evaluation plan", rep.evaluation_plan], ["Limitations", rep.limitations]].map(([h, items]) => items?.length > 0 && (
          <div className="list-block" key={h}><h3>{h}</h3><ul>{items.map((x, i) => <li key={i}>{x}</li>)}</ul></div>
        ))}
      </section>

      <section id="evidence">
        <h2>Evidence the agent drew on</h2>
        <p className="small muted">Every source was returned by a tool during this run. “Cited by” shows which options use it.</p>
        <div className="table-wrap">
          <table>
            <thead><tr><th>ID</th><th>Source</th><th>Year</th><th>Study type</th><th>Status</th><th>Cited by</th></tr></thead>
            <tbody>
              {evList.map((e) => (
                <tr key={e.id} className={picked === e.id ? "sel" : ""}>
                  <td><button className="cite" onClick={() => setPicked(e.id)}>{e.id}</button></td>
                  <td>{e.url ? <a href={e.url} target="_blank" rel="noreferrer noopener">{e.title}</a> : e.title}<div className="small muted">{e.source}</div></td>
                  <td>{(e.published || "").slice(0, 4)}</td>
                  <td>{e.study_type}</td>
                  <td><span className={`badge ${e.status}`} title={(STATUS[e.status] || [])[1]}>{(STATUS[e.status] || [e.status])[0]}</span></td>
                  <td>{e.cited_by?.join(", ") || <span className="muted">not cited</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {picked && ev[picked] && <SourceCard e={ev[picked]} onClose={() => setPicked(null)} />}
      </section>

      <section id="checks">
        <h2>Checks and method</h2>
        <p className="small muted">{val.note}</p>
        <p><b>Structural score {val.score}/100</b> after {r.attempts.length} drafting attempt(s).</p>
        <ul className="checks">{Object.entries(val.checks || {}).map(([k, ok]) => <li key={k} className={ok ? "ok" : "no"}><span aria-hidden="true">{ok ? "✓" : "✗"}</span> {k}</li>)}</ul>
        <dl className="facts">
          <dt>Harness</dt><dd>{prov.harness}</dd>
          <dt>MCP servers</dt><dd>{prov.mcp_servers.join(", ") || "none (in-process fallback tools)"}</dd>
          <dt>Subagents</dt><dd>{prov.subagents.join(", ")}</dd>
          <dt>Skills</dt><dd>{prov.skills.join(", ")}</dd>
          <dt>Tool calls</dt><dd>{Object.entries(prov.tool_calls).map(([k, v]) => `${k} ×${v}`).join(", ") || "none"}</dd>
          <dt>Versions</dt><dd>{prov.versions}</dd>
        </dl>
      </section>
    </article>
  );
}
